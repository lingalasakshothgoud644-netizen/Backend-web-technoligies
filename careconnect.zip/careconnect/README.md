# CareConnect – Doctor Appointment Booking (MERN)

Healthcare project #16. Patients sign in, the app detects their location, shows nearby hospitals/clinics, lets them search doctors (pulmonologist, dentist, …), book a free time slot, and ask a **Care Assistant chatbot** which doctor to see and what precautions to take.

| Layer | Technology |
|---|---|
| Database | **MongoDB** (Mongoose) – users, hospitals, doctors, appointments |
| Backend | **Node.js + Express** REST API, JWT login, role-based access |
| Frontend | **React 18** (Vite, React Router) |

## 1. Run it (5 minutes)

You need **Node.js 18+** and **MongoDB** (local install, or a free MongoDB Atlas cluster).

```bash
# 1. install everything
npm run install-all

# 2. configure the server
cp server/.env.example server/.env      # then set MONGO_URI and JWT_SECRET

# 3. fill the database with 17 hospitals/clinics and 94 sample doctors
npm run seed

# 4. start API (port 5000) + React app (port 5173)
npm run dev
```

Open **http://localhost:5173**. Allow the location prompt after signing in.

Demo logins (created by `npm run seed`):

| Role | Email | Password |
|---|---|---|
| Patient | patient@careconnect.test | Patient@123 |
| Doctor | ananya.kumar@careconnect.test | Doctor@123 (all doctors use this password) |
| Admin | admin@careconnect.test | Admin@123 |

Single-server mode: `npm run build` then `npm start` – Express serves the built React app on port 5000.

## 2. Features mapped to the problem statement

- **Authentication + role-based access** – patient / doctor / admin (JWT). Every page except Login needs sign-in.
- **CRUD with MongoDB** – hospitals, doctors (admin panel: add / edit / delete), appointments (book / reschedule / cancel / complete / delete).
- **REST APIs** with Express (table below).
- **React UI** – home, search, hospital page, doctor page + slot booking, my appointments, doctor schedule, admin panel.
- **Location** – browser geolocation after login → hospitals and doctors sorted by distance (haversine). Falls back to central Hyderabad if permission is denied.
- **17 hospitals/clinics** – Apollo, KIMS, Yashoda, CARE, Continental, AIG, Rainbow, Fernandez, Sunshine, Medicover, Gleneagles, Kamineni, NIMS, National Dental Care, Metrocare, Yuti, Ameerpet Dental. Each card shows a hospital photo with the **name printed clearly**; if the photo fails to load a brand-colour banner with the name is shown.
- **Search bar** – "pulmonologist", "dentist", "lung", "heart", "skin doctor", doctor name, hospital or area.
- **Slots** – each doctor has working hours; 30-minute slots are generated per date, booked ones are disabled, and a unique database index prevents double booking.
- **Care Assistant chatbot** – type a problem or use the symptom picker (symptom → severity). It returns the suggested specialist, general precautions, warning signs, and the nearest matching doctors with *Book* buttons. Emergency phrases (chest pain, can't breathe…) show 108/112 and the nearest 24×7 hospitals; self-harm phrases show Tele-MANAS 14416.

## 3. Folder structure and file types

```
careconnect/
├── package.json              scripts to install / seed / run both apps
├── README.md                 this guide (.md = Markdown text)
├── server/                   BACKEND (Node.js + Express)
│   ├── package.json          dependency list (.json)
│   ├── .env.example          settings template (.env = environment variables)
│   ├── test/logic.test.js    tests for chatbot, search, slots (npm test in server/)
│   └── src/
│       ├── index.js          starts Express, connects MongoDB, mounts routes
│       ├── seed.js           fills the database
│       ├── config/env.js     reads .env
│       ├── models/           Mongoose schemas: User, Hospital, Doctor, Appointment
│       ├── middleware/auth.js  JWT check + role check
│       ├── routes/           auth, hospitals, doctors, appointments, chat, admin
│       ├── utils/            geo.js (distance), slots.js (time slots),
│       │                     specialties.js (search + symptom catalog), chatbot.js
│       └── data/             hospitals.js, doctors.js (seed data)
└── client/                   FRONTEND (React)
    ├── index.html            page shell
    ├── vite.config.js        dev server + /api proxy to port 5000
    ├── public/assets/        chatbot-logo.jpeg and your reference images
    └── src/
        ├── main.jsx, App.jsx routes + role guards
        ├── api.js, utils.js  fetch helper, formatters
        ├── context/AppContext.jsx   login state + location
        ├── components/       Navbar, HospitalCard, DoctorCard, SlotPicker, ChatWidget, Avatar
        ├── pages/            Login, Home, Search, HospitalDetail, DoctorDetail,
        │                     MyAppointments, DoctorDashboard, Admin
        └── styles.css        all styling (responsive, dark-mode aware)
```

File types: `.js` server logic · `.jsx` React components (JavaScript + HTML-like tags) · `.css` styling · `.json` configuration · `.html` page shell · `.env` secrets/settings · `.md` documentation.

## 4. API reference

| Method & path | Who | Purpose |
|---|---|---|
| POST `/api/auth/register`, `/login` | public | create patient account / sign in |
| GET `/api/auth/me`, PUT `/api/auth/me/location` | signed in | current user / save detected location |
| GET `/api/hospitals?lat&lng&q&type&specialty` | signed in | hospitals sorted by distance |
| GET `/api/hospitals/:id` | signed in | hospital + its doctors |
| POST / PUT / DELETE `/api/hospitals` | admin | manage hospitals |
| GET `/api/doctors?q&specialty&hospital&lat&lng` | signed in | search doctors |
| GET `/api/doctors/:id`, `/api/doctors/:id/slots?date=` | signed in | profile / free slots |
| POST / PUT / DELETE `/api/doctors` | admin | manage doctors (optional doctor login) |
| GET `/api/appointments` | signed in | own (patient), assigned (doctor) or all (admin) |
| POST `/api/appointments` | patient | book |
| PUT `/api/appointments/:id` | owner / doctor / admin | reschedule, cancel, complete |
| DELETE `/api/appointments/:id` | admin | remove record |
| POST `/api/chat` | signed in | chatbot reply |
| GET `/api/admin/stats` | admin | dashboard numbers |

## 5. Important notes (read before presenting)

- **Sample data.** Doctors are fictional. Hospital coordinates are approximate and phone numbers/timings are placeholders – check each hospital's official site before using real details. Hospital photos are Unsplash stock images (internet needed).
- **The chatbot is rule-based**, not an AI model. It suggests *which type of doctor* and general precautions; it does not diagnose or recommend medicines. To upgrade it, replace the logic in `server/src/routes/chat.js` with an LLM API call and keep the emergency checks.
- No online payment or SMS/email confirmation – listed as future work.
- Change `JWT_SECRET` before any real deployment.

## 6. Ideas for extension

Google Maps embed, email/SMS reminders (Nodemailer), doctor ratings, online payment, multi-city data, doctor-managed leave days.
