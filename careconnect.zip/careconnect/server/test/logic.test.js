// Run with:  npm test   (no database needed)
const assert = require('assert');
const { analyze } = require('../src/utils/chatbot');
const { specialtiesForQuery } = require('../src/utils/specialties');
const { generateSlots } = require('../src/utils/slots');
const { distanceKm } = require('../src/utils/geo');
const hospitals = require('../src/data/hospitals');
const { buildDoctors } = require('../src/data/doctors');

const spec = (msg) => (analyze(msg).primary || {}).name;

// --- Chatbot: symptom -> specialty
assert.strictEqual(spec('I have a dry cough and wheezing'), 'Pulmonologist');
assert.strictEqual(spec('Breath shortness, severity: Mid (2-5 times)'), 'Pulmonologist');
assert.strictEqual(spec('my tooth hurts and gums are bleeding'), 'Dentist');
assert.strictEqual(spec('itchy rash on my arm'), 'Dermatologist');
assert.strictEqual(spec('I have fever and body ache'), 'General Physician');
assert.strictEqual(spec('my 3 year old has a cough'), 'Pediatrician');
assert.strictEqual(spec('I need a dentist'), 'Dentist');
assert.strictEqual(spec('knee pain while climbing stairs'), 'Orthopedic');
assert.strictEqual(spec('hello there'), undefined);

// --- Chatbot: safety
assert.ok(analyze('I have chest pain and sweating').emergency);
assert.ok(analyze("I can't breathe").emergency);
assert.ok(analyze('Breath shortness, severity: Severe (every hour)').emergency);
assert.ok(!analyze('mild cough since yesterday').emergency);
assert.ok(analyze('I want to die').selfHarm);

// --- Search-bar matching
const q = (s) => specialtiesForQuery(s).map((x) => x.name);
assert.deepStrictEqual(q('pulmonologist'), ['Pulmonologist']);
assert.ok(q('lung specialist').includes('Pulmonologist'));
assert.deepStrictEqual(q('dentist'), ['Dentist']);
assert.ok(q('skin doctor').includes('Dermatologist'));
assert.ok(q('ent').includes('ENT Specialist') && !q('ent').includes('Dentist'));

// --- Slots (2026-10-12 is a Monday)
const doc = { slotMinutes: 30, schedule: [{ days: [1], start: '09:00', end: '11:00' }, { days: [1], start: '16:00', end: '17:00' }] };
const future = new Date('2026-10-01T00:00:00Z');
assert.deepStrictEqual(generateSlots(doc, '2026-10-12', future), ['09:00', '09:30', '10:00', '10:30', '16:00', '16:30']);
assert.deepStrictEqual(generateSlots(doc, '2026-10-13', future), []); // Tuesday: not working
const now = new Date('2026-10-12T09:50:00Z'); // "today", 09:50 -> only later slots remain
assert.deepStrictEqual(generateSlots(doc, '2026-10-12', now), ['10:30', '16:00', '16:30']);

// --- Geo
assert.ok(Math.abs(distanceKm(17.4156, 78.4106, 17.4401, 78.4983) - 9.9) < 1.5);

// --- Seed data
assert.ok(hospitals.length >= 15 && hospitals.length <= 20);
const docs = buildDoctors(hospitals);
assert.ok(docs.length >= 60);
assert.strictEqual(new Set(docs.map((d) => d.email)).size, docs.length, 'doctor emails must be unique');
assert.strictEqual(new Set(docs.map((d) => d.name)).size, docs.length, 'doctor names must be unique');
docs.forEach((d) => assert.ok(d.qualification && d.schedule.length && d.fee > 0));

console.log(`All logic tests passed (${hospitals.length} hospitals, ${docs.length} doctors).`);
console.log('First doctor login:', docs[0].email);
