const router = require('express').Router();
const mongoose = require('mongoose');
const Hospital = require('../models/Hospital');
const Doctor = require('../models/Doctor');
const { protect, allow, wrap } = require('../middleware/auth');
const { distanceKm, readCoords } = require('../utils/geo');
const { specialtiesForQuery } = require('../utils/specialties');

const esc = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const FIELDS = ['name', 'type', 'area', 'address', 'city', 'lat', 'lng', 'image', 'color', 'logoText', 'phone', 'website', 'timings', 'emergency', 'specialties'];
const pick = (body) => Object.fromEntries(FIELDS.filter((f) => body[f] !== undefined).map((f) => [f, body[f]]));

// GET /api/hospitals?lat=&lng=&q=&type=&specialty=&emergency=true
// Returns hospitals sorted by distance when coordinates are given.
router.get('/', protect, wrap(async (req, res) => {
  const { q, type, specialty, emergency } = req.query;
  const coords = readCoords(req.query);
  const filter = {};
  if (type && type !== 'All') filter.type = type;
  if (emergency === 'true') filter.emergency = true;

  const or = [];
  if (q && q.trim()) {
    const rx = new RegExp(esc(q.trim()), 'i');
    or.push({ name: rx }, { area: rx }, { address: rx }, { specialties: rx });
    // "dentist" / "lung doctor" -> hospitals that have a doctor of that specialty
    const specs = specialtiesForQuery(q).map((s) => s.name);
    if (specs.length) or.push({ _id: { $in: await Doctor.distinct('hospital', { specialization: { $in: specs } }) } });
  }
  if (specialty && specialty !== 'All') {
    filter._id = { $in: await Doctor.distinct('hospital', { specialization: specialty }) };
  }
  if (or.length) filter.$or = or;

  const [hospitals, counts] = await Promise.all([
    Hospital.find(filter).lean(),
    Doctor.aggregate([{ $group: { _id: '$hospital', n: { $sum: 1 } } }]),
  ]);
  const countMap = new Map(counts.map((c) => [String(c._id), c.n]));
  let list = hospitals.map((h) => ({
    ...h,
    doctorCount: countMap.get(String(h._id)) || 0,
    distanceKm: coords ? distanceKm(coords.lat, coords.lng, h.lat, h.lng) : null,
  }));
  list.sort((a, b) => (coords ? a.distanceKm - b.distanceKm : a.name.localeCompare(b.name)));
  if (req.query.limit) list = list.slice(0, Math.max(1, parseInt(req.query.limit, 10) || 10));
  res.json({ hospitals: list });
}));

// GET /api/hospitals/:id  - hospital with its doctors
router.get('/:id', protect, wrap(async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: 'Hospital not found' });
  const hospital = await Hospital.findById(req.params.id).lean();
  if (!hospital) return res.status(404).json({ message: 'Hospital not found' });
  const doctors = await Doctor.find({ hospital: hospital._id }).sort({ specialization: 1, experienceYears: -1 }).lean();
  const coords = readCoords(req.query);
  if (coords) hospital.distanceKm = distanceKm(coords.lat, coords.lng, hospital.lat, hospital.lng);
  res.json({ hospital, doctors });
}));

// ---- Admin only (CRUD) ----
router.post('/', protect, allow('admin'), wrap(async (req, res) => {
  const h = await Hospital.create(pick(req.body));
  res.status(201).json({ hospital: h });
}));

router.put('/:id', protect, allow('admin'), wrap(async (req, res) => {
  const h = await Hospital.findByIdAndUpdate(req.params.id, pick(req.body), { new: true, runValidators: true });
  if (!h) return res.status(404).json({ message: 'Hospital not found' });
  res.json({ hospital: h });
}));

router.delete('/:id', protect, allow('admin'), wrap(async (req, res) => {
  if (await Doctor.exists({ hospital: req.params.id })) {
    return res.status(409).json({ message: 'Remove or move this hospital’s doctors first' });
  }
  const h = await Hospital.findByIdAndDelete(req.params.id);
  if (!h) return res.status(404).json({ message: 'Hospital not found' });
  res.json({ ok: true });
}));

module.exports = router;
