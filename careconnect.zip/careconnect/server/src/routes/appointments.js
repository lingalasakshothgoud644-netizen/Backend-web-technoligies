const router = require('express').Router();
const mongoose = require('mongoose');
const Appointment = require('../models/Appointment');
const Doctor = require('../models/Doctor');
const { protect, allow, wrap } = require('../middleware/auth');
const { generateSlots, isValidDate, inBookingWindow } = require('../utils/slots');

const populate = (q) =>
  q.populate('doctor', 'name specialization qualification fee')
    .populate('hospital', 'name area address phone lat lng color logoText')
    .populate('patient', 'name email phone');

// Checks that (doctor, date, time) is a real, free slot. Returns an error message or null.
async function slotProblem(doctor, date, time) {
  if (!isValidDate(date || '') || !/^\d{2}:\d{2}$/.test(time || '')) return 'Please choose a valid date and time';
  if (!inBookingWindow(date)) return 'Appointments can be booked from today up to 30 days ahead';
  if (!generateSlots(doctor, date).includes(time)) return 'That time is not available for this doctor';
  return null;
}

const isDuplicate = (e) => e && e.code === 11000;

// GET /api/appointments  - patients see their own, doctors see theirs, admins see all
router.get('/', protect, wrap(async (req, res) => {
  const filter = {};
  if (req.user.role === 'patient') filter.patient = req.user._id;
  if (req.user.role === 'doctor') {
    const d = await Doctor.findOne({ user: req.user._id });
    if (!d) return res.json({ appointments: [] });
    filter.doctor = d._id;
  }
  if (req.query.status) filter.status = req.query.status;
  const appointments = await populate(Appointment.find(filter).sort({ date: 1, time: 1 })).lean();
  res.json({ appointments });
}));

// POST /api/appointments  { doctorId, date, time, reason }   (patients)
router.post('/', protect, allow('patient'), wrap(async (req, res) => {
  const { doctorId, date, time, reason } = req.body || {};
  if (!mongoose.isValidObjectId(doctorId)) return res.status(400).json({ message: 'Choose a doctor' });
  const doctor = await Doctor.findById(doctorId);
  if (!doctor) return res.status(404).json({ message: 'Doctor not found' });
  const problem = await slotProblem(doctor, date, time);
  if (problem) return res.status(400).json({ message: problem });
  if (await Appointment.exists({ patient: req.user._id, date, time, status: 'booked' })) {
    return res.status(409).json({ message: 'You already have another appointment at that time' });
  }
  try {
    const appt = await Appointment.create({
      patient: req.user._id, doctor: doctor._id, hospital: doctor.hospital,
      department: doctor.specialization, date, time, reason,
    });
    res.status(201).json({ appointment: await populate(Appointment.findById(appt._id)).lean() });
  } catch (e) {
    if (isDuplicate(e)) return res.status(409).json({ message: 'Sorry, that slot was just booked. Please pick another time.' });
    throw e;
  }
}));

// PUT /api/appointments/:id
//   { date, time }  -> reschedule (owner patient or admin)
//   { status }      -> 'cancelled' (patient/doctor/admin) or 'completed' (doctor/admin)
router.put('/:id', protect, wrap(async (req, res) => {
  const appt = await Appointment.findById(req.params.id);
  if (!appt) return res.status(404).json({ message: 'Appointment not found' });

  const myDoctor = req.user.role === 'doctor' ? await Doctor.findOne({ user: req.user._id }) : null;
  const isOwner = String(appt.patient) === String(req.user._id);
  const isTheirDoctor = myDoctor && String(appt.doctor) === String(myDoctor._id);
  if (!(req.user.role === 'admin' || isOwner || isTheirDoctor)) return res.status(403).json({ message: 'Not allowed' });
  if (appt.status !== 'booked') return res.status(409).json({ message: `This appointment is already ${appt.status}` });

  const { date, time, status } = req.body || {};
  if (date || time) {
    if (!(isOwner || req.user.role === 'admin')) return res.status(403).json({ message: 'Only the patient can reschedule' });
    const doctor = await Doctor.findById(appt.doctor);
    const problem = await slotProblem(doctor, date, time);
    if (problem) return res.status(400).json({ message: problem });
    appt.date = date; appt.time = time;
  }
  if (status) {
    if (!['cancelled', 'completed'].includes(status)) return res.status(400).json({ message: 'Invalid status' });
    if (status === 'completed' && isOwner && req.user.role === 'patient') return res.status(403).json({ message: 'Only the doctor can complete a visit' });
    appt.status = status;
  }
  try {
    await appt.save();
  } catch (e) {
    if (isDuplicate(e)) return res.status(409).json({ message: 'That slot was just booked. Please pick another time.' });
    throw e;
  }
  res.json({ appointment: await populate(Appointment.findById(appt._id)).lean() });
}));

// DELETE /api/appointments/:id  (admin: permanently remove a record)
router.delete('/:id', protect, allow('admin'), wrap(async (req, res) => {
  const a = await Appointment.findByIdAndDelete(req.params.id);
  if (!a) return res.status(404).json({ message: 'Appointment not found' });
  res.json({ ok: true });
}));

module.exports = router;
