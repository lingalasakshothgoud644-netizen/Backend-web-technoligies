const router = require('express').Router();
const User = require('../models/User');
const Hospital = require('../models/Hospital');
const Doctor = require('../models/Doctor');
const Appointment = require('../models/Appointment');
const { protect, allow, wrap } = require('../middleware/auth');
const { todayStr } = require('../utils/slots');

// GET /api/admin/stats
router.get('/stats', protect, allow('admin'), wrap(async (req, res) => {
  const [patients, hospitals, doctors, byStatus, upcoming, perSpec] = await Promise.all([
    User.countDocuments({ role: 'patient' }),
    Hospital.countDocuments(),
    Doctor.countDocuments(),
    Appointment.aggregate([{ $group: { _id: '$status', n: { $sum: 1 } } }]),
    Appointment.countDocuments({ status: 'booked', date: { $gte: todayStr() } }),
    Appointment.aggregate([{ $group: { _id: '$department', n: { $sum: 1 } } }, { $sort: { n: -1 } }, { $limit: 5 }]),
  ]);
  res.json({
    patients, hospitals, doctors, upcoming,
    appointments: Object.fromEntries(byStatus.map((s) => [s._id, s.n])),
    topDepartments: perSpec.map((p) => ({ department: p._id, count: p.n })),
  });
}));

module.exports = router;
