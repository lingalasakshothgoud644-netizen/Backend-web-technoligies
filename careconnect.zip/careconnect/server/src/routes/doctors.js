const router = require('express').Router();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const Doctor = require('../models/Doctor');
const Hospital = require('../models/Hospital');
const Appointment = require('../models/Appointment');
const User = require('../models/User');
const { protect, allow, wrap } = require('../middleware/auth');
const { distanceKm, readCoords } = require('../utils/geo');
const { specialtiesForQuery, names } = require('../utils/specialties');
const { generateSlots, isValidDate, inBookingWindow } = require('../utils/slots');

const esc = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const FIELDS = ['name', 'specialization', 'department', 'qualification', 'experienceYears', 'fee', 'languages', 'about', 'gender', 'hospital', 'slotMinutes', 'schedule'];
const pick = (body) => Object.fromEntries(FIELDS.filter((f) => body[f] !== undefined).map((f) => [f, body[f]]));

// GET /api/doctors/meta/specialties
router.get('/meta/specialties', protect, (req, res) => res.json({ specialties: names }));

// GET /api/doctors?q=&specialty=&hospital=&lat=&lng=&limit=
// Search by doctor name, specialty ("pulmonologist", "dentist", "lung"), or hospital name.
router.get('/', protect, wrap(async (req, res) => {
  const { q, specialty, hospital } = req.query;
  const coords = readCoords(req.query);
  const filter = {};
  if (specialty && specialty !== 'All') filter.specialization = specialty;
  if (hospital && mongoose.isValidObjectId(hospital)) filter.hospital = hospital;

  if (q && q.trim()) {
    const rx = new RegExp(esc(q.trim()), 'i');
    const specs = specialtiesForQuery(q).map((s) => s.name);
    const hospIds = await Hospital.distinct('_id', { $or: [{ name: rx }, { area: rx }] });
    filter.$or = [{ name: rx }, { specialization: rx }, { hospital: { $in: hospIds } }];
    if (specs.length) filter.$or.push({ specialization: { $in: specs } });
  }

  const docs = await Doctor.find(filter).populate('hospital', 'name area address lat lng color logoText type').lean();
  let list = docs.filter((d) => d.hospital).map((d) => ({
    ...d,
    distanceKm: coords ? distanceKm(coords.lat, coords.lng, d.hospital.lat, d.hospital.lng) : null,
  }));
  list.sort((a, b) => (coords ? a.distanceKm - b.distanceKm || b.experienceYears - a.experienceYears : b.experienceYears - a.experienceYears));
  if (req.query.limit) list = list.slice(0, Math.max(1, parseInt(req.query.limit, 10) || 12));
  res.json({ doctors: list });
}));

// GET /api/doctors/:id
router.get('/:id', protect, wrap(async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: 'Doctor not found' });
  const doctor = await Doctor.findById(req.params.id).populate('hospital').lean();
  if (!doctor) return res.status(404).json({ message: 'Doctor not found' });
  res.json({ doctor });
}));

// GET /api/doctors/:id/slots?date=YYYY-MM-DD  -> [{time:'09:00', available:true}, ...]
router.get('/:id/slots', protect, wrap(async (req, res) => {
  const { date } = req.query;
  if (!isValidDate(date || '')) return res.status(400).json({ message: 'Please provide a valid date (YYYY-MM-DD)' });
  const doctor = await Doctor.findById(req.params.id).lean();
  if (!doctor) return res.status(404).json({ message: 'Doctor not found' });
  if (!inBookingWindow(date)) return res.json({ date, slots: [] });
  const booked = new Set(await Appointment.distinct('time', { doctor: doctor._id, date, status: 'booked' }));
  const slots = generateSlots(doctor, date).map((time) => ({ time, available: !booked.has(time) }));
  res.json({ date, slots });
}));

// ---- Admin only (CRUD) ----
router.post('/', protect, allow('admin'), wrap(async (req, res) => {
  const { loginEmail, loginPassword } = req.body;
  const data = pick(req.body);
  if (!(await Hospital.exists({ _id: data.hospital }))) return res.status(400).json({ message: 'Choose a valid hospital' });
  if (loginEmail && loginPassword) {
    if (await User.exists({ email: loginEmail.toLowerCase() })) return res.status(409).json({ message: 'Login email already in use' });
    const u = await User.create({ name: data.name, email: loginEmail, role: 'doctor', password: await bcrypt.hash(loginPassword, 10) });
    data.user = u._id;
  }
  const doctor = await Doctor.create(data);
  await Hospital.findByIdAndUpdate(data.hospital, { $addToSet: { specialties: data.specialization } });
  res.status(201).json({ doctor });
}));

router.put('/:id', protect, allow('admin'), wrap(async (req, res) => {
  const doctor = await Doctor.findByIdAndUpdate(req.params.id, pick(req.body), { new: true, runValidators: true });
  if (!doctor) return res.status(404).json({ message: 'Doctor not found' });
  await Hospital.findByIdAndUpdate(doctor.hospital, { $addToSet: { specialties: doctor.specialization } });
  res.json({ doctor });
}));

router.delete('/:id', protect, allow('admin'), wrap(async (req, res) => {
  const doctor = await Doctor.findById(req.params.id);
  if (!doctor) return res.status(404).json({ message: 'Doctor not found' });
  if (await Appointment.exists({ doctor: doctor._id, status: 'booked' })) {
    return res.status(409).json({ message: 'This doctor has active appointments. Cancel them first.' });
  }
  if (doctor.user) await User.findByIdAndDelete(doctor.user);
  await doctor.deleteOne();
  res.json({ ok: true });
}));

module.exports = router;
