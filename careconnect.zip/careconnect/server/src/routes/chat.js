const router = require('express').Router();
const Doctor = require('../models/Doctor');
const Hospital = require('../models/Hospital');
const { protect, wrap } = require('../middleware/auth');
const { analyze, QUICK_SYMPTOMS } = require('../utils/chatbot');
const { distanceKm, readCoords } = require('../utils/geo');

const DISCLAIMER = 'This is general guidance, not a diagnosis or a prescription. A doctor needs to examine you.';

async function nearbyDoctors(specialization, coords, n = 4) {
  const docs = await Doctor.find({ specialization }).populate('hospital', 'name area address lat lng color logoText').lean();
  return docs
    .filter((d) => d.hospital)
    .map((d) => ({ ...d, distanceKm: coords ? distanceKm(coords.lat, coords.lng, d.hospital.lat, d.hospital.lng) : null }))
    .sort((a, b) => (coords ? a.distanceKm - b.distanceKm || b.experienceYears - a.experienceYears : b.experienceYears - a.experienceYears))
    .slice(0, n);
}

async function nearestEmergencyHospitals(coords, n = 3) {
  const list = await Hospital.find({ emergency: true }).lean();
  return list
    .map((h) => ({ ...h, distanceKm: coords ? distanceKm(coords.lat, coords.lng, h.lat, h.lng) : null }))
    .sort((a, b) => (coords ? a.distanceKm - b.distanceKm : 0))
    .slice(0, n);
}

// POST /api/chat  { message, lat?, lng? }
router.post('/', protect, wrap(async (req, res) => {
  const message = String(req.body.message || '').trim().slice(0, 500);
  if (!message) return res.status(400).json({ message: 'Please type your question' });
  const coords = readCoords(req.body);
  const r = analyze(message);

  if (r.selfHarm) {
    return res.json({
      type: 'support',
      message: "I'm really sorry you're going through this. You don't have to face it alone. Please reach out right now to someone who can help: call Tele-MANAS at 14416 (free, 24x7 mental-health support in India), or call 112 if you are in immediate danger. If you can, tell a family member or friend near you.",
    });
  }

  if (r.emergency) {
    return res.json({
      type: 'emergency',
      message: 'What you describe could be an emergency. Please call 108 / 112 or go to the nearest emergency department immediately. Do not wait for an appointment or for this chat.',
      hospitals: await nearestEmergencyHospitals(coords),
    });
  }

  if (!r.primary) {
    return res.json({
      type: 'clarify',
      message: "I couldn't match that to a specialty yet. Tell me your main symptom, how long you've had it, and whether you have fever or pain - or pick a symptom below.",
      options: QUICK_SYMPTOMS,
    });
  }

  const { SPECIALTIES } = require('../utils/specialties');
  const s = SPECIALTIES.find((x) => x.name === r.primary.name);
  res.json({
    type: 'advice',
    specialty: s.name,
    why: s.why,
    precautions: s.precautions,
    warn: s.warn,
    alsoConsider: r.also ? r.also.name : null,
    urgent: r.severe,
    urgentMessage: r.severe ? 'You marked your symptoms as severe. Please do not wait for a routine appointment - visit a hospital emergency department today.' : null,
    doctors: await nearbyDoctors(s.name, coords),
    hospitals: r.severe ? await nearestEmergencyHospitals(coords) : undefined,
    disclaimer: DISCLAIMER,
  });
}));

// GET /api/chat/symptoms  -> list used by the symptom picker in the chat widget
router.get('/symptoms', protect, (req, res) => res.json({ symptoms: QUICK_SYMPTOMS }));

module.exports = router;
