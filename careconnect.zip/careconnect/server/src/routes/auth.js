const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { protect, wrap } = require('../middleware/auth');
const { JWT_SECRET, JWT_EXPIRES_IN } = require('../config/env');
const { readCoords } = require('../utils/geo');

const sign = (user) => jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
const publicUser = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role, phone: u.phone, location: u.location });

// POST /api/auth/register  - patients self-register (doctor/admin accounts are created by an admin)
router.post('/register', wrap(async (req, res) => {
  const { name, email, password, phone } = req.body || {};
  if (!name || !email || !password) return res.status(400).json({ message: 'Name, email and password are required' });
  if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ message: 'Please enter a valid email' });
  if (password.length < 6) return res.status(400).json({ message: 'Password must be at least 6 characters' });
  if (await User.findOne({ email: email.toLowerCase() })) return res.status(409).json({ message: 'An account with this email already exists' });
  const user = await User.create({ name, email, phone, password: await bcrypt.hash(password, 10), role: 'patient' });
  res.status(201).json({ token: sign(user), user: publicUser(user) });
}));

// POST /api/auth/login
router.post('/login', wrap(async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ message: 'Email and password are required' });
  const user = await User.findOne({ email: String(email).toLowerCase() }).select('+password');
  if (!user || !(await bcrypt.compare(password, user.password))) return res.status(401).json({ message: 'Incorrect email or password' });
  res.json({ token: sign(user), user: publicUser(user) });
}));

// GET /api/auth/me
router.get('/me', protect, (req, res) => res.json({ user: publicUser(req.user) }));

// PUT /api/auth/me/location  - saves the location detected by the browser
router.put('/me/location', protect, wrap(async (req, res) => {
  const c = readCoords(req.body);
  if (!c) return res.status(400).json({ message: 'Invalid location' });
  req.user.location = { ...c, label: req.body.label };
  await req.user.save();
  res.json({ user: publicUser(req.user) });
}));

module.exports = router;
