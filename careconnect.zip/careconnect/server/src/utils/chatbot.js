// Rule-based symptom assistant. It suggests WHICH TYPE of doctor to see and general
// precautions. It does not diagnose and never recommends prescription medicines.
const { SPECIALTIES, aliasMatches } = require('./specialties');

const EMERGENCY =
  /chest pain|pain in (my )?chest|can'?t breathe|cannot breathe|struggling to breathe|severe breathing|unconscious|passed out|fainted|stroke|face droop|slurred speech|seizure|convulsion|heavy bleeding|coughing (up )?blood|vomiting blood|poison|overdose|snake bite|heart attack/i;
const SELF_HARM = /suicid|kill myself|end my life|want to die|self[- ]?harm|hurt myself/i;
const SEVERE = /severity:\s*severe|unbearable|very severe|worst (pain|headache)/i;

function analyze(message) {
  const m = String(message).toLowerCase();
  const selfHarm = SELF_HARM.test(m);
  const severe = SEVERE.test(m);
  const emergency = EMERGENCY.test(m) || (severe && /breath|chest/.test(m));

  // 1) The user asked for a specialist directly ("I need a dentist")
  const explicit = SPECIALTIES.find((s) =>
    [s.name.toLowerCase(), ...s.aliases.filter((a) => a.length >= 5 || a === 'ent')].some((a) => aliasMatches(m, a) && m.includes(a))
  );

  // 2) Score symptom keywords
  const scored = SPECIALTIES.map((s) => {
    let score = s.keywords.filter((k) => m.includes(k)).length;
    if (s.name === 'General Physician') score *= 0.6; // prefer a specific specialty when both match
    return { spec: s, score };
  })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score);

  const isChild = /\b(child|kid|baby|infant|toddler|newborn|my son|my daughter)\b|\b\d{1,2}\s?(month|year)s?\s?old\b/.test(m);
  let primary = explicit || (scored[0] && scored[0].spec) || null;
  if (isChild && primary && primary.name !== 'Pediatrician' && !explicit) {
    primary = SPECIALTIES.find((s) => s.name === 'Pediatrician');
  }
  let also = scored.map((x) => x.spec).filter((s) => primary && s.name !== primary.name)[0];
  if (primary && !also && primary.name !== 'General Physician') also = SPECIALTIES.find((s) => s.name === 'General Physician');

  return { selfHarm, emergency, severe, primary, also, isChild, explicit: !!explicit };
}

const QUICK_SYMPTOMS = [
  'Fever', 'Cough', 'Breath shortness', 'Chest pain', 'Headache', 'Stomach pain',
  'Skin rash', 'Tooth pain', 'Joint pain', 'Anxiety', 'Eye pain', 'Ear pain',
];

module.exports = { analyze, QUICK_SYMPTOMS };
