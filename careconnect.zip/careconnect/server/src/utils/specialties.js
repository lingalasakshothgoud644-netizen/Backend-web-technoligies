// Catalog of medical specialties.
//  - aliases   : words a user may type in the search bar ("lung doctor", "dentist" ...)
//  - keywords  : symptom words the chatbot looks for
//  - precautions / warn : general self-care and red-flag guidance (NOT a diagnosis, no medicine doses)
const SPECIALTIES = [
  {
    name: 'General Physician',
    aliases: ['general physician', 'general doctor', 'physician', 'gp', 'family doctor', 'general medicine', 'fever doctor'],
    keywords: ['fever', 'cold', 'flu', 'body ache', 'body pain', 'weakness', 'fatigue', 'tired', 'headache', 'viral', 'chills', 'loss of appetite', 'sore throat'],
    qual: 'MBBS, MD (General Medicine)',
    fee: 500,
    why: 'A general physician is the best first stop for common problems such as fever, cold, weakness or body pain, and can refer you to a specialist if needed.',
    precautions: [
      'Rest well and drink plenty of fluids (water, ORS, soups).',
      'Eat light, freshly cooked food.',
      'Note your temperature and when the symptoms started - the doctor will ask.',
      'Ask a doctor or pharmacist before taking any medicine.',
    ],
    warn: ['Fever for more than 3 days or above 103°F (39.4°C)', 'Severe headache with stiff neck or confusion', 'You cannot keep fluids down', 'Symptoms are getting worse quickly'],
  },
  {
    name: 'Pulmonologist',
    aliases: ['pulmonologist', 'pulmonology', 'lung', 'lungs', 'chest specialist', 'respiratory', 'asthma doctor', 'breathing'],
    keywords: ['cough', 'breath', 'breathing', 'breathless', 'shortness of breath', 'breath shortness', 'wheez', 'asthma', 'lungs', 'chest congestion', 'phlegm', 'sputum', 'snoring'],
    qual: 'MBBS, MD (Pulmonary Medicine)',
    fee: 800,
    why: 'Cough that lasts, wheezing, or breathing difficulty are handled by a pulmonologist (lung specialist).',
    precautions: [
      'Avoid smoke, dust, strong fragrances and cold drinks for now.',
      'Sit upright, take slow deep breaths and keep the room well ventilated.',
      'Keep warm fluids handy; steam inhalation can soothe a dry throat.',
      'Keep a note of triggers (dust, weather, exercise) and how long the cough has lasted.',
    ],
    warn: ['Breathing becomes difficult or you cannot speak full sentences', 'Lips or fingertips look bluish', 'Coughing up blood', 'Cough lasting more than 2-3 weeks'],
  },
  {
    name: 'Cardiologist',
    aliases: ['cardiologist', 'cardiology', 'heart', 'heart doctor', 'bp doctor'],
    keywords: ['palpitation', 'heartbeat', 'heart beat', 'heart', 'blood pressure', 'bp', 'chest tightness', 'chest discomfort', 'swollen feet', 'cholesterol'],
    qual: 'MBBS, MD, DM (Cardiology)',
    fee: 900,
    why: 'Heart-related symptoms such as palpitations, high blood pressure or chest discomfort should be checked by a cardiologist.',
    precautions: [
      'Avoid heavy exertion, smoking, alcohol and very salty food until you are checked.',
      'Sit and rest; keep track of your pulse and blood pressure if you have a monitor.',
      'Carry your previous reports, ECG and medicine list to the visit.',
    ],
    warn: ['Chest pain or pressure spreading to the arm, jaw or back', 'Fainting or severe dizziness', 'Sudden sweating with breathlessness'],
  },
  {
    name: 'Dentist',
    aliases: ['dentist', 'dental', 'tooth', 'teeth', 'dentistry'],
    keywords: ['tooth', 'teeth', 'toothache', 'gum', 'gums', 'cavity', 'mouth sore', 'wisdom', 'jaw pain', 'bleeding gums', 'bad breath', 'mouth ulcer'],
    qual: 'BDS, MDS',
    fee: 400,
    why: 'Tooth pain, gum problems and mouth sores are treated by a dentist.',
    precautions: [
      'Rinse gently with lukewarm salt water; brush softly with a soft brush.',
      'Avoid very hot, cold or sugary food and chewing on the painful side.',
      'Do not place any tablet or chemical directly on the gum or tooth.',
    ],
    warn: ['Facial swelling or fever with tooth pain', 'Difficulty swallowing or opening the mouth', 'Bleeding that does not stop'],
  },
  {
    name: 'Dermatologist',
    aliases: ['dermatologist', 'dermatology', 'skin', 'skin doctor', 'hair doctor', 'skin specialist'],
    keywords: ['skin', 'rash', 'itch', 'itching', 'acne', 'pimple', 'hair fall', 'hair loss', 'dandruff', 'eczema', 'allergy', 'fungal', 'redness', 'hives'],
    qual: 'MBBS, MD (Dermatology)',
    fee: 700,
    why: 'Skin, hair and nail problems are handled by a dermatologist.',
    precautions: [
      'Avoid scratching and do not apply steroid creams without a prescription.',
      'Keep the area clean and dry; wear loose cotton clothing.',
      'Note any new soap, cosmetic or food that may have triggered it.',
    ],
    warn: ['Rapidly spreading rash with fever', 'Swelling of face, lips or tongue', 'Blisters or painful peeling skin'],
  },
  {
    name: 'Pediatrician',
    aliases: ['pediatrician', 'paediatrician', 'pediatric', 'child specialist', 'child doctor', 'kids doctor', 'baby doctor'],
    keywords: ['child', 'baby', 'infant', 'toddler', 'newborn', 'my son', 'my daughter', 'kid', 'vaccination', 'vaccine'],
    qual: 'MBBS, MD (Pediatrics)',
    fee: 650,
    why: 'Children are best examined by a pediatrician, who knows age-specific causes and safe doses.',
    precautions: [
      'Keep the child hydrated and dressed comfortably; offer small, frequent feeds.',
      'Track temperature, feeding, wet diapers and activity level.',
      'Never give adult medicines or aspirin to a child - ask the pediatrician first.',
    ],
    warn: ['Baby under 3 months with any fever', 'Fast or laboured breathing, or the child is very drowsy', 'Not feeding or passing urine for 8+ hours', 'Seizure or bluish lips'],
  },
  {
    name: 'Gynecologist',
    aliases: ['gynecologist', 'gynaecologist', 'gynecology', 'gynaecology', 'obgyn', 'ob-gyn', 'obstetrician', "women's doctor", 'womens health', 'pregnancy doctor'],
    keywords: ['period', 'periods', 'menstrual', 'pregnan', 'pcos', 'pcod', 'vaginal', 'white discharge', 'irregular cycle', 'menopause', 'breast lump'],
    qual: 'MBBS, MD/MS (Obstetrics & Gynaecology)',
    fee: 800,
    why: "Menstrual, pregnancy and other women's health concerns are handled by a gynecologist.",
    precautions: [
      'Track your cycle dates and symptoms on a calendar or app.',
      'Stay hydrated, rest, and eat iron-rich food if you are bleeding heavily.',
      'If pregnant, do not start or stop any medicine without medical advice.',
    ],
    warn: ['Very heavy bleeding (soaking a pad every hour)', 'Severe pelvic pain', 'Bleeding or severe pain during pregnancy'],
  },
  {
    name: 'Orthopedic',
    aliases: ['orthopedic', 'orthopaedic', 'ortho', 'bone doctor', 'bone', 'joint', 'orthopedician', 'spine'],
    keywords: ['joint pain', 'knee', 'back pain', 'neck pain', 'shoulder', 'fracture', 'sprain', 'arthritis', 'bone', 'hip pain', 'ankle', 'muscle pain', 'swelling in joint'],
    qual: 'MBBS, MS (Orthopaedics)',
    fee: 800,
    why: 'Bone, joint, muscle and spine problems are treated by an orthopedic doctor.',
    precautions: [
      'Rest the affected part and avoid heavy lifting or sudden twisting.',
      'A cold pack wrapped in cloth for 10-15 minutes may ease swelling after an injury.',
      'Do not massage a suspected fracture; keep the limb supported.',
    ],
    warn: ['Obvious deformity or you cannot bear weight', 'Numbness or weakness in the limb', 'Back pain with loss of bladder/bowel control'],
  },
  {
    name: 'Neurologist',
    aliases: ['neurologist', 'neurology', 'brain doctor', 'nerve'],
    keywords: ['migraine', 'numbness', 'tingling', 'dizziness', 'vertigo', 'memory', 'tremor', 'nerve', 'blackout', 'severe headache'],
    qual: 'MBBS, MD, DM (Neurology)',
    fee: 1000,
    why: 'Migraine, numbness, dizziness and nerve-related problems are handled by a neurologist.',
    precautions: [
      'Rest in a quiet, dim room and keep well hydrated.',
      'Maintain regular sleep and meals; note possible triggers.',
      'Write down when each episode happens and how long it lasts.',
    ],
    warn: ['Sudden weakness on one side, face drooping or slurred speech', 'Worst headache of your life', 'Fainting or a seizure'],
  },
  {
    name: 'Gastroenterologist',
    aliases: ['gastroenterologist', 'gastro', 'gastroenterology', 'stomach doctor', 'digestive', 'liver doctor'],
    keywords: ['stomach', 'vomit', 'vomiting', 'nausea', 'diarrhea', 'diarrhoea', 'loose motion', 'constipation', 'acidity', 'gas', 'bloating', 'abdominal', 'indigestion', 'heartburn', 'jaundice'],
    qual: 'MBBS, MD, DM (Gastroenterology)',
    fee: 900,
    why: 'Stomach pain, vomiting, loose motions and digestion problems are treated by a gastroenterologist.',
    precautions: [
      'Sip ORS or clean water often to prevent dehydration.',
      'Eat light food (rice, banana, curd) and avoid spicy, oily food and alcohol.',
      'Wash hands well and drink only safe, boiled or filtered water.',
    ],
    warn: ['Blood in vomit or stool', 'Severe stomach pain or a hard, swollen belly', 'Signs of dehydration (dry mouth, very little urine, dizziness)'],
  },
  {
    name: 'ENT Specialist',
    aliases: ['ent', 'ent specialist', 'ear nose throat', 'throat doctor', 'ear doctor'],
    keywords: ['ear', 'earache', 'hearing', 'nose', 'sinus', 'tonsil', 'throat pain', 'blocked nose', 'nose bleed', 'voice', 'sneezing', 'runny nose'],
    qual: 'MBBS, MS (ENT)',
    fee: 700,
    why: 'Ear, nose and throat problems such as sinus trouble, ear pain and tonsils are handled by an ENT specialist.',
    precautions: [
      'Do not put oil, drops or objects in the ear unless a doctor advises it.',
      'Steam inhalation and warm fluids can ease a blocked nose or sore throat.',
      'Avoid cold drinks, dust and smoke.',
    ],
    warn: ['Sudden hearing loss', 'Heavy nosebleed that does not stop in 15 minutes', 'Difficulty swallowing or breathing'],
  },
  {
    name: 'Ophthalmologist',
    aliases: ['ophthalmologist', 'ophthalmology', 'eye doctor', 'eye specialist', 'eye', 'eyes'],
    keywords: ['eye', 'eyes', 'vision', 'blurry', 'blurred', 'red eye', 'eye pain', 'watery eyes', 'itchy eyes', 'cataract'],
    qual: 'MBBS, MS (Ophthalmology)',
    fee: 600,
    why: 'Eye pain, redness or vision changes should be seen by an ophthalmologist (eye doctor).',
    precautions: [
      "Don't rub your eyes; wash hands before touching them.",
      'Remove contact lenses and avoid screens for a while.',
      "Don't use leftover eye drops without a doctor's advice.",
    ],
    warn: ['Sudden loss of vision', 'Severe eye pain, or an injury / chemical splash to the eye', 'Seeing flashes of light or a curtain over the vision'],
  },
  {
    name: 'Endocrinologist',
    aliases: ['endocrinologist', 'endocrinology', 'diabetologist', 'diabetes doctor', 'thyroid doctor', 'hormone doctor'],
    keywords: ['diabetes', 'sugar', 'thyroid', 'hormone', 'weight gain', 'weight loss', 'excess thirst', 'frequent urination'],
    qual: 'MBBS, MD, DM (Endocrinology)',
    fee: 900,
    why: 'Diabetes, thyroid and hormone problems are managed by an endocrinologist.',
    precautions: [
      'Keep your regular meal timings and avoid sugary drinks.',
      'Bring recent blood sugar / thyroid reports and your current medicine list.',
      'Do not change or stop any medicine on your own.',
    ],
    warn: ['Blood sugar very high or very low with confusion', 'Fruity-smelling breath with vomiting', 'Fainting or extreme drowsiness'],
  },
  {
    name: 'Psychiatrist',
    aliases: ['psychiatrist', 'psychiatry', 'mental health', 'psychologist', 'counsellor', 'counselor', 'therapist'],
    keywords: ['anxiety', 'depression', 'depressed', 'stress', 'panic', 'insomnia', 'sleep problem', 'cannot sleep', "can't sleep", 'sad', 'mood', 'overthinking'],
    qual: 'MBBS, MD (Psychiatry)',
    fee: 1000,
    why: 'Anxiety, low mood, stress and sleep problems are treated by a psychiatrist.',
    precautions: [
      'Talk to someone you trust; you do not have to handle this alone.',
      'Keep a regular sleep routine, light exercise and limit caffeine and alcohol.',
      'Try slow breathing: inhale for 4 counts, exhale for 6, for a few minutes.',
    ],
    warn: ['Thoughts of harming yourself or others', 'Not eating or sleeping for several days', 'Hearing or seeing things others do not'],
  },
  {
    name: 'Urologist',
    aliases: ['urologist', 'urology', 'kidney doctor', 'kidney', 'urine doctor'],
    keywords: ['urine', 'urinary', 'kidney', 'stone', 'burning urination', 'uti', 'prostate', 'blood in urine'],
    qual: 'MBBS, MS, MCh (Urology)',
    fee: 900,
    why: 'Urine problems, kidney stones and prostate issues are handled by a urologist.',
    precautions: [
      'Drink plenty of water unless a doctor has restricted fluids.',
      'Do not hold urine for long; avoid very salty food.',
      'Note colour of urine, pain location and any fever.',
    ],
    warn: ['Severe flank pain with vomiting', 'Unable to pass urine', 'Blood in urine with fever'],
  },
];

const names = SPECIALTIES.map((s) => s.name);
const byName = (n) => SPECIALTIES.find((s) => s.name.toLowerCase() === String(n).toLowerCase());

// true if the typed text refers to the alias (short aliases like "ent" need an exact word)
function aliasMatches(query, alias) {
  const q = query.toLowerCase().trim();
  if (q.length < 2) return false;
  const tokens = q.split(/[^a-z']+/);
  if (alias.length <= 3) return tokens.includes(alias);
  return q.includes(alias) || (q.length >= 4 && alias.includes(q));
}

// Specialties a search-bar query refers to, e.g. "lung specialist" -> [Pulmonologist]
function specialtiesForQuery(query) {
  return SPECIALTIES.filter(
    (s) => aliasMatches(query, s.name.toLowerCase()) || s.aliases.some((a) => aliasMatches(query, a))
  );
}

module.exports = { SPECIALTIES, names, byName, specialtiesForQuery, aliasMatches };
