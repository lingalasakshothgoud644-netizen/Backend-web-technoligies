const { TZ_OFFSET_MIN } = require('../config/env');

const toMin = (t) => {
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
};
const fmt = (m) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;

// "Now" in the clinic's time zone (default India, UTC+5:30)
function nowLocal() {
  return new Date(Date.now() + TZ_OFFSET_MIN * 60000);
}
const todayStr = () => nowLocal().toISOString().slice(0, 10);
const isValidDate = (d) => /^\d{4}-\d{2}-\d{2}$/.test(d) && !Number.isNaN(Date.parse(d));

// Returns all slot start times ("HH:MM") a doctor works on a given date (ignores bookings)
function generateSlots(doctor, date, now = nowLocal()) {
  const dow = new Date(`${date}T00:00:00Z`).getUTCDay();
  const step = doctor.slotMinutes || 30;
  const isToday = date === now.toISOString().slice(0, 10);
  const nowMin = now.getUTCHours() * 60 + now.getUTCMinutes();
  const out = new Set();
  for (const block of doctor.schedule || []) {
    if (!block.days.includes(dow)) continue;
    for (let t = toMin(block.start); t + step <= toMin(block.end); t += step) {
      if (isToday && t <= nowMin + 15) continue; // slot already started / starting too soon
      out.add(fmt(t));
    }
  }
  return [...out].sort();
}

// Booking window: today .. today + 30 days
function inBookingWindow(date) {
  const today = todayStr();
  const max = new Date(Date.parse(today) + 30 * 86400000).toISOString().slice(0, 10);
  return date >= today && date <= max;
}

module.exports = { generateSlots, isValidDate, inBookingWindow, todayStr, toMin };
