const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, select: false },
    role: { type: String, enum: ['patient', 'doctor', 'admin'], default: 'patient' },
    phone: { type: String, trim: true },
    // Last known location of the patient (saved after the browser shares it)
    location: { lat: Number, lng: Number, label: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model('User', userSchema);
