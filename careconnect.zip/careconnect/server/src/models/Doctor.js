const mongoose = require('mongoose');

const scheduleSchema = new mongoose.Schema(
  {
    days: [{ type: Number, min: 0, max: 6 }], // 0 = Sunday ... 6 = Saturday
    start: { type: String, required: true }, // "09:00"
    end: { type: String, required: true }, // "13:00"
  },
  { _id: false }
);

const doctorSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    specialization: { type: String, required: true, trim: true }, // e.g. Pulmonologist
    department: { type: String, trim: true },
    qualification: String,
    experienceYears: { type: Number, default: 1, min: 0 },
    fee: { type: Number, default: 500, min: 0 },
    languages: [String],
    about: String,
    gender: { type: String, enum: ['F', 'M'], default: 'M' },
    hospital: { type: mongoose.Schema.Types.ObjectId, ref: 'Hospital', required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // login account of the doctor (optional)
    slotMinutes: { type: Number, default: 30, min: 10, max: 120 },
    schedule: [scheduleSchema],
  },
  { timestamps: true }
);

doctorSchema.index({ specialization: 1 });

module.exports = mongoose.model('Doctor', doctorSchema);
