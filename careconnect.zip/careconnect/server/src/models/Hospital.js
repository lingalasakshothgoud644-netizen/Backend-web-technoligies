const mongoose = require('mongoose');

const hospitalSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    type: { type: String, enum: ['Hospital', 'Clinic', 'Dental'], default: 'Hospital' },
    area: { type: String, required: true, trim: true },
    address: { type: String, required: true, trim: true },
    city: { type: String, default: 'Hyderabad' },
    lat: { type: Number, required: true },
    lng: { type: Number, required: true },
    image: String,
    color: { type: String, default: '#1769aa' }, // brand colour used on the banner
    logoText: String, // short name shown big on the banner (e.g. "KIMS")
    phone: String,
    website: String,
    timings: { type: String, default: 'Open 24 hours' },
    emergency: { type: Boolean, default: false },
    specialties: [String],
  },
  { timestamps: true }
);

module.exports = mongoose.model('Hospital', hospitalSchema);
