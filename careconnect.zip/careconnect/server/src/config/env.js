require('dotenv').config();

if (!process.env.JWT_SECRET) {
  console.warn('[warn] JWT_SECRET is not set - using an insecure development default. Set it in server/.env');
}

module.exports = {
  PORT: Number(process.env.PORT) || 5000,
  MONGO_URI: process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/careconnect',
  JWT_SECRET: process.env.JWT_SECRET || 'dev-secret-change-me',
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',
  CLIENT_URL: process.env.CLIENT_URL || 'http://localhost:5173',
  TZ_OFFSET_MIN: Number(process.env.TZ_OFFSET_MIN ?? 330),
};
