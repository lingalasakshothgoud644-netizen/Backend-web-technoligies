// Builds sample doctor profiles (pure function - no database needed).
// All doctors are FICTIONAL sample data for the project demo.
const { byName } = require('../utils/specialties');

const FEMALE = ['Ananya', 'Priya', 'Neha', 'Kavya', 'Sneha', 'Lakshmi', 'Divya', 'Meera', 'Anjali', 'Swathi', 'Pooja', 'Harini', 'Sowmya', 'Nandini', 'Rekha', 'Shruti', 'Aditi', 'Bhavana', 'Keerthi', 'Madhavi'];
const MALE = ['Rahul', 'Arjun', 'Vikram', 'Suresh', 'Karthik', 'Ravi', 'Sandeep', 'Naveen', 'Prasad', 'Imran', 'Rohit', 'Venkat', 'Anil', 'Srinivas', 'Harsha', 'Manoj', 'Faisal', 'Girish', 'Deepak', 'Tarun'];
const LAST = ['Rao', 'Reddy', 'Sharma', 'Kumar', 'Mehta', 'Singh', 'Naidu', 'Iyer', 'Khan', 'Gupta', 'Patel', 'Varma', 'Chowdary', 'Murthy', 'Shetty', 'Nair', 'Menon', 'Joshi', 'Bhat', 'Das', 'Pillai', 'Raju', 'Sastry', 'Goud', 'Yadav', 'Verma', 'Kulkarni', 'Desai', 'Ali', 'Hussain', 'Siddiqui', 'Agarwal', 'Krishnan', 'Subramanian', 'Bose', 'Banerjee', 'Kapoor'];
const LANGS = [['English', 'Telugu', 'Hindi'], ['English', 'Telugu'], ['English', 'Hindi', 'Urdu'], ['English', 'Telugu', 'Tamil']];

const MON_SAT = [1, 2, 3, 4, 5, 6];
const MON_FRI = [1, 2, 3, 4, 5];
const PATTERNS = [
  [{ days: MON_SAT, start: '09:00', end: '13:00' }, { days: MON_SAT, start: '16:00', end: '19:00' }],
  [{ days: MON_FRI, start: '10:00', end: '14:00' }, { days: MON_FRI, start: '17:00', end: '20:00' }],
  [{ days: [1, 3, 5], start: '09:30', end: '13:30' }, { days: [2, 4], start: '15:00', end: '18:00' }, { days: [6], start: '10:00', end: '14:00' }],
  [{ days: MON_SAT, start: '11:00', end: '17:00' }],
];

const slug = (s) => s.toLowerCase().replace(/[^a-z]/g, '');

function buildDoctors(hospitals) {
  const out = [];
  let i = 0;
  hospitals.forEach((h, hIndex) => {
    h.departments.forEach((dept) => {
      const gender = i % 2 === 0 ? 'F' : 'M';
      const first = (gender === 'F' ? FEMALE : MALE)[(i >> 1) % 20];
      const last = LAST[(i * 7 + 3) % LAST.length];
      const spec = byName(dept);
      const exp = 5 + ((i * 5 + 3) % 22);
      out.push({
        hospitalIndex: hIndex,
        name: `Dr. ${first} ${last}`,
        email: `${slug(first)}.${slug(last)}@careconnect.test`,
        gender,
        specialization: dept,
        department: dept,
        qualification: spec.qual,
        experienceYears: exp,
        fee: Math.round((spec.fee + (exp > 15 ? 200 : 0) + (h.type === 'Hospital' ? 0 : -100)) / 50) * 50,
        languages: LANGS[i % LANGS.length],
        about: `${dept} with ${exp} years of experience at ${h.name}. (Sample profile for the project demo.)`,
        slotMinutes: 30,
        schedule: PATTERNS[(i + hIndex) % PATTERNS.length],
      });
      i++;
    });
  });
  return out;
}

module.exports = { buildDoctors };
