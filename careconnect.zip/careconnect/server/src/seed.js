// Fills the database with demo data:  npm run seed   (WARNING: clears existing collections)
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { MONGO_URI } = require('./config/env');
const User = require('./models/User');
const Hospital = require('./models/Hospital');
const Doctor = require('./models/Doctor');
const Appointment = require('./models/Appointment');
const hospitalData = require('./data/hospitals');
const { buildDoctors } = require('./data/doctors');

(async () => {
  await mongoose.connect(MONGO_URI);
  await Promise.all([User.deleteMany({}), Hospital.deleteMany({}), Doctor.deleteMany({}), Appointment.deleteMany({})]);
  await Appointment.syncIndexes();

  const hospitals = await Hospital.insertMany(
    hospitalData.map(({ departments, ...h }) => ({ ...h, specialties: [...new Set(departments)] }))
  );

  const hash = (p) => bcrypt.hash(p, 10);
  const [adminPw, patientPw, doctorPw] = await Promise.all([hash('Admin@123'), hash('Patient@123'), hash('Doctor@123')]);
  await User.create([
    { name: 'CareConnect Admin', email: 'admin@careconnect.test', password: adminPw, role: 'admin' },
    { name: 'Demo Patient', email: 'patient@careconnect.test', password: patientPw, role: 'patient', phone: '9876543210' },
  ]);

  const docs = buildDoctors(hospitalData);
  const users = await User.insertMany(docs.map((d) => ({ name: d.name, email: d.email, password: doctorPw, role: 'doctor' })));
  await Doctor.insertMany(
    docs.map(({ hospitalIndex, email, ...d }, i) => ({ ...d, hospital: hospitals[hospitalIndex]._id, user: users[i]._id }))
  );

  console.log(`Seeded ${hospitals.length} hospitals/clinics and ${docs.length} doctors.\n`);
  console.log('Demo logins');
  console.log('  Patient : patient@careconnect.test / Patient@123');
  console.log('  Admin   : admin@careconnect.test   / Admin@123');
  console.log(`  Doctor  : ${docs[0].email} / Doctor@123   (every doctor uses Doctor@123)`);
  await mongoose.disconnect();
})().catch((e) => {
  console.error('Seeding failed:', e.message);
  process.exit(1);
});
