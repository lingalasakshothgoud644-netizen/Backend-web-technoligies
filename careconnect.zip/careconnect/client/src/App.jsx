import { Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { useApp } from './context/AppContext.jsx';
import Navbar from './components/Navbar.jsx';
import ChatWidget from './components/ChatWidget.jsx';
import Login from './pages/Login.jsx';
import Home from './pages/Home.jsx';
import Search from './pages/Search.jsx';
import HospitalDetail from './pages/HospitalDetail.jsx';
import DoctorDetail from './pages/DoctorDetail.jsx';
import MyAppointments from './pages/MyAppointments.jsx';
import DoctorDashboard from './pages/DoctorDashboard.jsx';
import Admin from './pages/Admin.jsx';

// Every page except /login needs the user to be signed in
function Protected() {
  const { user, loading } = useApp();
  const location = useLocation();
  if (loading) return <div className="center-screen"><div className="spinner" /></div>;
  if (!user) return <Navigate to="/login" state={{ from: location.pathname + location.search }} replace />;
  return (
    <div className="app">
      <Navbar />
      <Outlet />
      {user.role === 'patient' && <ChatWidget />}
      <footer className="footer">
        CareConnect · MERN project prototype · Not a medical service. Doctor profiles and slots are sample data; in an emergency call 108 / 112.
      </footer>
    </div>
  );
}

// Only lets certain roles in (role based access control)
function RoleOnly({ roles, children }) {
  const { user } = useApp();
  return roles.includes(user.role) ? children : <Navigate to="/" replace />;
}

function HomeRouter() {
  const { user } = useApp();
  if (user.role === 'doctor') return <Navigate to="/doctor" replace />;
  if (user.role === 'admin') return <Navigate to="/admin" replace />;
  return <Home />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route element={<Protected />}>
        <Route path="/" element={<HomeRouter />} />
        <Route path="/search" element={<RoleOnly roles={['patient']}><Search /></RoleOnly>} />
        <Route path="/hospitals/:id" element={<RoleOnly roles={['patient']}><HospitalDetail /></RoleOnly>} />
        <Route path="/doctors/:id" element={<RoleOnly roles={['patient']}><DoctorDetail /></RoleOnly>} />
        <Route path="/appointments" element={<RoleOnly roles={['patient']}><MyAppointments /></RoleOnly>} />
        <Route path="/doctor" element={<RoleOnly roles={['doctor']}><DoctorDashboard /></RoleOnly>} />
        <Route path="/admin" element={<RoleOnly roles={['admin']}><Admin /></RoleOnly>} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
