import { Link } from 'react-router-dom';
import Avatar from './Avatar.jsx';
import { scheduleText } from '../utils';

export default function DoctorCard({ d, compact }) {
  return (
    <article className="doctor">
      <Avatar name={d.name} gender={d.gender} size={compact ? 52 : 68} />
      <div className="doctor-info">
        <h3>{d.name}</h3>
        <div className="specialty">{d.specialization}</div>
        <div className="muted small">{d.qualification} · {d.experienceYears} yrs experience</div>
        {d.hospital?.name && (
          <div className="muted small">
            🏥 <Link to={`/hospitals/${d.hospital._id}`}>{d.hospital.name}</Link>, {d.hospital.area}
            {d.distanceKm != null && <b> · {d.distanceKm} km</b>}
          </div>
        )}
        {!compact && d.schedule?.length > 0 && <div className="muted small">🕘 {scheduleText(d.schedule)}</div>}
        <div className="doctor-actions">
          <span className="fee">₹{d.fee}</span>
          <Link className="primary sm" to={`/doctors/${d._id}`}>Book appointment</Link>
        </div>
      </div>
    </article>
  );
}
