import { useState } from 'react';
import { Link } from 'react-router-dom';
import { directionsLink } from '../utils';

// Hospital photo with the hospital name printed clearly on it.
// If the photo can't load, a branded colour banner is shown instead so the name is always visible.
export function HospitalBanner({ h, tall }) {
  const [broken, setBroken] = useState(false);
  return (
    <div className={`hbanner ${tall ? 'tall' : ''}`} style={{ '--brand': h.color || '#1769aa' }}>
      {h.image && !broken && <img src={h.image} alt={`${h.name} building`} loading="lazy" onError={() => setBroken(true)} />}
      <div className="hbanner-shade" />
      <span className="hbanner-logo">{h.logoText || h.name}</span>
      <div className="hbanner-name">{h.name}</div>
      {h.emergency && <span className="badge emergency">24×7 Emergency</span>}
      {h.distanceKm != null && <span className="badge dist">⌖ {h.distanceKm} km</span>}
    </div>
  );
}

export default function HospitalCard({ h }) {
  return (
    <article className="hospital">
      <Link to={`/hospitals/${h._id}`} aria-label={`Open ${h.name}`}>
        <HospitalBanner h={h} />
      </Link>
      <div className="hospital-body">
        <div className="muted">⌖ {h.area}, {h.city || 'Hyderabad'} · {h.type}</div>
        <div className="muted small">🕘 {h.timings}</div>
        <div className="tagrow">
          {(h.specialties || []).slice(0, 4).map((s) => <span className="tag" key={s}>{s}</span>)}
          {(h.specialties || []).length > 4 && <span className="tag">+{h.specialties.length - 4} more</span>}
        </div>
        <div className="hospital-foot">
          <a className="muted" href={directionsLink(h)} target="_blank" rel="noopener noreferrer">Directions ↗</a>
          <Link className="small-btn" to={`/hospitals/${h._id}`}>{h.doctorCount ?? ''} doctors · Book →</Link>
        </div>
      </div>
    </article>
  );
}
