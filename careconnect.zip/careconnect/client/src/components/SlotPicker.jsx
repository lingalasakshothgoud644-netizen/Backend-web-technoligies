import { useEffect, useMemo, useState } from 'react';
import { api } from '../api';
import { DAY_NAMES, fmtTime, ymd } from '../utils';

// Shows the next 14 days; days the doctor doesn't work on are disabled.
// After a date is chosen, the available time slots for that day are loaded from the API.
export default function SlotPicker({ doctor, value, onChange }) {
  const days = useMemo(() => {
    const start = new Date();
    return Array.from({ length: 14 }, (_, i) => {
      const d = new Date(start.getFullYear(), start.getMonth(), start.getDate() + i);
      return { date: ymd(d), dow: d.getDay(), num: d.getDate(), month: d.toLocaleString('en-IN', { month: 'short' }) };
    });
  }, []);
  const works = (dow) => (doctor.schedule || []).some((s) => s.days.includes(dow));

  const [date, setDate] = useState(value?.date || days.find((d) => works(d.dow))?.date);
  const [slots, setSlots] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!date) return;
    let live = true;
    setSlots(null);
    setError('');
    api(`/doctors/${doctor._id}/slots`, { params: { date } })
      .then((d) => live && setSlots(d.slots))
      .catch((e) => live && setError(e.message));
    return () => { live = false; };
  }, [doctor._id, date]);

  const groups = [
    ['Morning', (t) => t < '12:00'],
    ['Afternoon', (t) => t >= '12:00' && t < '16:00'],
    ['Evening', (t) => t >= '16:00'],
  ];
  const free = slots ? slots.filter((s) => s.available).length : 0;

  return (
    <div className="slotpicker">
      <h4>Choose a date</h4>
      <div className="datestrip">
        {days.map((d) => (
          <button
            key={d.date}
            type="button"
            disabled={!works(d.dow)}
            className={`datebtn ${date === d.date ? 'active' : ''}`}
            onClick={() => { setDate(d.date); onChange(null); }}
          >
            <small>{DAY_NAMES[d.dow]}</small>
            <b>{d.num}</b>
            <small>{d.month}</small>
          </button>
        ))}
      </div>

      <h4>
        Available time slots {slots && <span className="muted small">· {free} free</span>}
      </h4>
      {error && <p className="error">{error}</p>}
      {!slots && !error && <p className="muted">Loading slots…</p>}
      {slots && slots.length === 0 && <p className="muted">No slots on this day. Try another date.</p>}
      {slots && slots.length > 0 && free === 0 && <p className="muted">All slots are booked on this day. Try another date.</p>}
      {slots && groups.map(([label, test]) => {
        const g = slots.filter((s) => test(s.time));
        if (!g.length) return null;
        return (
          <div key={label} className="slotgroup">
            <div className="muted small">{label}</div>
            <div className="slots">
              {g.map((s) => (
                <button
                  key={s.time}
                  type="button"
                  disabled={!s.available}
                  className={`slot ${value?.time === s.time && value?.date === date ? 'active' : ''}`}
                  title={s.available ? 'Available' : 'Already booked'}
                  onClick={() => onChange({ date, time: s.time })}
                >
                  {fmtTime(s.time)}
                </button>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
