import { NavLink, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext.jsx';

export default function Navbar() {
  const { user, logout } = useApp();
  const nav = useNavigate();
  const links = {
    patient: [['/', 'Home'], ['/search', 'Find care'], ['/appointments', 'My appointments']],
    doctor: [['/doctor', 'My schedule']],
    admin: [['/admin', 'Admin panel']],
  }[user.role];

  return (
    <header className="topbar">
      <NavLink to="/" className="brand">
        <span className="brandmark">✚</span>Care<span>Connect</span>
      </NavLink>
      <nav className="nav">
        {links.map(([to, label]) => (
          <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => (isActive ? 'active' : '')}>
            {label}
          </NavLink>
        ))}
      </nav>
      <div className="userbox">
        <span className="who">
          <b>{user.name}</b>
          <small>{user.role}</small>
        </span>
        <button className="secondary" onClick={() => { logout(); nav('/login'); }}>Sign out</button>
      </div>
    </header>
  );
}
