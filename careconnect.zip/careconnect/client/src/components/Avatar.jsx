// Initials avatar with a colour derived from the name (no external images needed)
export default function Avatar({ name = '', gender, size = 64 }) {
  const initials = name.replace(/^Dr\.?\s*/i, '').split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();
  let hue = 0;
  for (const ch of name) hue = (hue * 31 + ch.charCodeAt(0)) % 360;
  return (
    <div
      className="avatar"
      style={{ width: size, height: size, fontSize: size * 0.36, background: `linear-gradient(135deg,hsl(${hue} 65% 45%),hsl(${(hue + 40) % 360} 65% 38%))` }}
      aria-label={name}
      title={gender === 'F' ? 'Female doctor' : undefined}
    >
      {initials}
    </div>
  );
}
