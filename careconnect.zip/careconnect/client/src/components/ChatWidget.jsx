import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../context/AppContext.jsx';
import DoctorCard from './DoctorCard.jsx';

const SYMPTOMS = [
  ['Fever', '🌡️'], ['Cough', '😷'], ['Breath shortness', '🫁'], ['Chest pain', '❤️'],
  ['Headache', '🤕'], ['Stomach pain', '🤢'], ['Skin rash', '🧴'], ['Tooth pain', '🦷'],
  ['Joint pain', '🦴'], ['Anxiety', '💬'], ['Eye pain', '👁️'], ['Ear pain', '👂'],
];
const SEVERITY = [
  ['Low', '1–2 times'], ['Mid', '2–5 times'], ['Moderate', 'more than 5 times'], ['Severe', 'every hour'],
];

// Assistant card showing the answer to the patient
function BotAnswer({ r, ask }) {
  if (r.type === 'text') return <div className="bubble bot">{r.message}</div>;
  if (r.type === 'support') return <div className="bubble bot support">{r.message}</div>;
  if (r.type === 'clarify')
    return (
      <div className="bubble bot">
        {r.message}
        <div className="chips-inline">
          {r.options.map((o) => <button key={o} onClick={() => ask(o)}>{o}</button>)}
        </div>
      </div>
    );
  if (r.type === 'emergency')
    return (
      <div className="bubble bot danger">
        <b>⚠ Possible emergency</b>
        <p>{r.message}</p>
        <div className="callrow"><a href="tel:108">📞 Ambulance 108</a><a href="tel:112">📞 Emergency 112</a></div>
        {r.hospitals?.length > 0 && <div className="small"><b>Nearest emergency hospitals</b></div>}
        {r.hospitals?.map((h) => (
          <div key={h._id} className="mini-row"><Link to={`/hospitals/${h._id}`}>{h.name}</Link><span>{h.distanceKm != null ? `${h.distanceKm} km` : h.area}</span></div>
        ))}
      </div>
    );

  // normal advice
  return (
    <div className="bubble bot advice">
      {r.urgent && <div className="urgent">⚠ {r.urgentMessage}</div>}
      <div className="advice-title">Suggested doctor: <b>{r.specialty}</b></div>
      <p>{r.why}</p>
      <div className="advice-h">What you can do for now</div>
      <ul>{r.precautions.map((p) => <li key={p}>{p}</li>)}</ul>
      <div className="advice-h warn">See a doctor urgently if</div>
      <ul>{r.warn.map((p) => <li key={p}>{p}</li>)}</ul>
      {r.hospitals?.length > 0 && (
        <>
          <div className="advice-h warn">Nearest emergency hospitals</div>
          {r.hospitals.map((h) => (
            <div key={h._id} className="mini-row"><Link to={`/hospitals/${h._id}`}>{h.name}</Link><span>{h.distanceKm != null ? `${h.distanceKm} km` : h.area}</span></div>
          ))}
        </>
      )}
      <div className="advice-h">Best {r.specialty}s near you</div>
      {r.doctors.length === 0 && <p className="muted">No {r.specialty} found nearby yet.</p>}
      <div className="chat-doctors">
        {r.doctors.map((d) => <DoctorCard key={d._id} d={d} compact />)}
      </div>
      {r.alsoConsider && (
        <div className="chips-inline">
          <span className="muted small">You could also see:</span>
          <button onClick={() => ask(`I need a ${r.alsoConsider}`)}>{r.alsoConsider}</button>
        </div>
      )}
      <div className="muted small disclaimer">{r.disclaimer}</div>
    </div>
  );
}

export default function ChatWidget() {
  const { coords } = useApp();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [input, setInput] = useState('');
  const [picker, setPicker] = useState(null); // null | 'symptoms' | {symptom}
  const [msgs, setMsgs] = useState([
    { from: 'bot', r: { type: 'text', message: 'Hi! I\'m your CareConnect assistant. Tell me what you\'re feeling, or pick a symptom, and I\'ll suggest which doctor to see, what precautions to take, and the best doctors near you. I can\'t diagnose conditions or prescribe medicines.' } },
  ]);
  const end = useRef(null);
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs, busy, picker, open]);

  async function ask(text) {
    const message = text.trim();
    if (!message || busy) return;
    setPicker(null);
    setInput('');
    setMsgs((m) => [...m, { from: 'user', text: message }]);
    setBusy(true);
    try {
      const r = await api('/chat', { method: 'POST', body: { message, lat: coords.lat, lng: coords.lng } });
      setMsgs((m) => [...m, { from: 'bot', r }]);
    } catch (e) {
      setMsgs((m) => [...m, { from: 'bot', r: { type: 'text', message: `Sorry, something went wrong: ${e.message}` } }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <button className="chat-launch" onClick={() => setOpen((o) => !o)} aria-label="Open care assistant">
        <img src="/assets/chatbot-logo.jpeg" alt="" /> {open ? 'Close' : 'Ask Care Assistant'}
      </button>
      {open && (
        <section className="chat-panel" aria-label="Care assistant">
          <div className="chat-head">
            <img src="/assets/chatbot-logo.jpeg" alt="" />
            <div><strong>Care Assistant</strong><small>Symptom guide · finds the right doctor</small></div>
            <button onClick={() => setOpen(false)} aria-label="Close chat">×</button>
          </div>

          <div className="chat-messages">
            {msgs.map((m, i) =>
              m.from === 'user'
                ? <div key={i} className="bubble user">{m.text}</div>
                : <BotAnswer key={i} r={m.r} ask={ask} />
            )}
            {busy && <div className="bubble bot typing"><span /><span /><span /></div>}
            <div ref={end} />
          </div>

          {/* Symptom picker: choose symptom -> choose severity -> send */}
          {picker === 'symptoms' && (
            <div className="picker">
              <div className="picker-head"><b>Select symptom</b><button onClick={() => setPicker(null)}>×</button></div>
              <div className="symgrid">
                {SYMPTOMS.map(([s, icon]) => (
                  <button key={s} onClick={() => setPicker({ symptom: s })}><span>{icon}</span>{s}</button>
                ))}
              </div>
            </div>
          )}
          {picker && picker.symptom && (
            <div className="picker">
              <div className="picker-head"><b>{picker.symptom}</b><button onClick={() => setPicker(null)}>×</button></div>
              <p className="muted small">How severe is it?</p>
              <div className="sevlist">
                {SEVERITY.map(([label, hint]) => (
                  <button key={label} onClick={() => ask(`${picker.symptom}, severity: ${label} (${hint})`)}>
                    <b>{label}</b><small>({hint})</small>
                  </button>
                ))}
              </div>
              <button className="secondary sm" onClick={() => setPicker('symptoms')}>← Back</button>
            </div>
          )}

          <form className="chat-form" onSubmit={(e) => { e.preventDefault(); ask(input); }}>
            <button type="button" className="secondary sm" onClick={() => setPicker('symptoms')} title="Pick a symptom">＋ Symptoms</button>
            <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Describe your problem…" aria-label="Message" maxLength={300} />
            <button className="primary sm" disabled={busy}>Send</button>
          </form>
          <div className="chat-note">Emergency (chest pain, severe breathing trouble, unconsciousness)? Call 108 / 112 now.</div>
        </section>
      )}
    </>
  );
}
