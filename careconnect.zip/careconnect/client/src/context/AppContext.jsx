import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { api, getToken, setToken } from '../api';
import { DEFAULT_COORDS } from '../utils';

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

export function AppProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!getToken());
  const [coords, setCoords] = useState(DEFAULT_COORDS);
  const [locStatus, setLocStatus] = useState('idle'); // idle | asking | granted | denied | unsupported
  const [toast, setToast] = useState('');

  const notify = useCallback((msg) => {
    setToast(msg);
    setTimeout(() => setToast(''), 3200);
  }, []);

  // Restore the session on page load
  useEffect(() => {
    if (!getToken()) return;
    api('/auth/me')
      .then((d) => {
        setUser(d.user);
        if (d.user.location?.lat) setCoords({ lat: d.user.location.lat, lng: d.user.location.lng, label: 'Your saved location', source: 'profile' });
      })
      .catch(() => setToken(null))
      .finally(() => setLoading(false));
  }, []);

  // Ask the browser for the patient's location, remember it on the account
  const detectLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setLocStatus('unsupported');
      return;
    }
    setLocStatus('asking');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const c = { lat: pos.coords.latitude, lng: pos.coords.longitude, label: 'Your current location', source: 'gps' };
        setCoords(c);
        setLocStatus('granted');
        if (getToken()) api('/auth/me/location', { method: 'PUT', body: { lat: c.lat, lng: c.lng, label: c.label } }).catch(() => {});
      },
      () => setLocStatus('denied'),
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
    );
  }, []);

  const login = (token, u) => {
    setToken(token);
    setUser(u);
    if (u.location?.lat) setCoords({ lat: u.location.lat, lng: u.location.lng, label: 'Your saved location', source: 'profile' });
    if (u.role === 'patient') setTimeout(detectLocation, 300); // detect location right after sign in
  };
  const logout = () => {
    setToken(null);
    setUser(null);
    setCoords(DEFAULT_COORDS);
    setLocStatus('idle');
  };

  return (
    <Ctx.Provider value={{ user, loading, login, logout, coords, locStatus, detectLocation, notify }}>
      {children}
      {toast && <div className="toast show">{toast}</div>}
    </Ctx.Provider>
  );
}
