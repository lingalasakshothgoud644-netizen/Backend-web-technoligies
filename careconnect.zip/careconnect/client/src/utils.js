export const DEFAULT_COORDS = { lat: 17.385, lng: 78.4867, label: 'Hyderabad (default)', source: 'default' };

// "13:30" -> "1:30 PM"
export function fmtTime(t) {
  const [h, m] = t.split(':').map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`;
}

// "2026-10-12" -> "Mon, 12 Oct 2026"
export function fmtDate(d) {
  return new Date(`${d}T00:00:00`).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}

// Local YYYY-MM-DD (not UTC) for a Date
export const ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

// Turns a doctor's schedule into text: "Mon–Sat · 9:00 AM–1:00 PM, 4:00 PM–7:00 PM"
export function scheduleText(schedule = []) {
  const groups = new Map();
  schedule.forEach((s) => {
    const key = [...s.days].sort().join(',');
    groups.set(key, [...(groups.get(key) || []), `${fmtTime(s.start)}–${fmtTime(s.end)}`]);
  });
  return [...groups.entries()]
    .map(([days, times]) => {
      const d = days.split(',').map(Number);
      const contiguous = d.length > 2 && d.every((x, i) => i === 0 || x === d[i - 1] + 1);
      const label = contiguous ? `${DAY_NAMES[d[0]]}–${DAY_NAMES[d[d.length - 1]]}` : d.map((x) => DAY_NAMES[x]).join(', ');
      return `${label} · ${times.join(', ')}`;
    })
    .join('  |  ');
}

export const mapsLink = (h) => `https://www.google.com/maps/search/?api=1&query=${h.lat},${h.lng}`;
export const directionsLink = (h) => `https://www.google.com/maps/dir/?api=1&destination=${h.lat},${h.lng}`;

export const SPECIALTY_ICONS = {
  'General Physician': '🩺', Pulmonologist: '🫁', Cardiologist: '❤️', Dentist: '🦷', Dermatologist: '🧴',
  Pediatrician: '🧒', Gynecologist: '🌸', Orthopedic: '🦴', Neurologist: '🧠', Gastroenterologist: '🍽️',
  'ENT Specialist': '👂', Ophthalmologist: '👁️', Endocrinologist: '🧬', Psychiatrist: '💬', Urologist: '💧',
};
