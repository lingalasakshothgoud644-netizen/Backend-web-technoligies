import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../context/AppContext.jsx';
import { HospitalBanner } from '../components/HospitalCard.jsx';
import DoctorCard from '../components/DoctorCard.jsx';
import { directionsLink } from '../utils';

export default function HospitalDetail() {
  const { id } = useParams();
  const { coords } = useApp();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [dept, setDept] = useState('All');

  useEffect(() => {
    api(`/hospitals/${id}`, { params: { lat: coords.lat, lng: coords.lng } }).then(setData).catch((e) => setError(e.message));
  }, [id, coords.lat, coords.lng]);

  const depts = useMemo(() => (data ? [...new Set(data.doctors.map((d) => d.specialization))] : []), [data]);

  if (error) return <main className="main"><p className="error">{error}</p><Link to="/search?tab=hospitals">← Back to hospitals</Link></main>;
  if (!data) return <main className="main"><div className="spinner" /></main>;
  const { hospital: h, doctors } = data;
  const shown = dept === 'All' ? doctors : doctors.filter((d) => d.specialization === dept);

  return (
    <main className="main">
      <Link className="back" to="/search?tab=hospitals">← All hospitals & clinics</Link>
      <HospitalBanner h={h} tall />
      <div className="info-grid">
        <div className="info-card"><small>Address</small><b>{h.address}</b></div>
        <div className="info-card"><small>Timings</small><b>{h.timings}</b></div>
        <div className="info-card"><small>Phone</small><b>{h.phone || '—'}</b></div>
        <div className="info-card"><small>Distance</small><b>{h.distanceKm != null ? `${h.distanceKm} km away` : '—'}</b></div>
      </div>
      <div className="row-actions">
        <a className="primary" href={directionsLink(h)} target="_blank" rel="noopener noreferrer">Get directions ↗</a>
        {h.website && <a className="secondary" href={h.website} target="_blank" rel="noopener noreferrer">Official website ↗</a>}
      </div>

      <div className="section-head">
        <div><h2>Doctors at {h.name}</h2><p>{doctors.length} doctors · experience, fees and timings shown on each card.</p></div>
        <select value={dept} onChange={(e) => setDept(e.target.value)} aria-label="Department">
          <option value="All">All departments</option>
          {depts.map((d) => <option key={d}>{d}</option>)}
        </select>
      </div>
      <div className="doctors">{shown.map((d) => <DoctorCard key={d._id} d={{ ...d, hospital: undefined }} />)}</div>
    </main>
  );
}
