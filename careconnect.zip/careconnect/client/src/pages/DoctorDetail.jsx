import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../api';
import Avatar from '../components/Avatar.jsx';
import SlotPicker from '../components/SlotPicker.jsx';
import { directionsLink, fmtDate, fmtTime, scheduleText } from '../utils';

export default function DoctorDetail() {
  const { id } = useParams();
  const [doctor, setDoctor] = useState(null);
  const [error, setError] = useState('');
  const [pick, setPick] = useState(null);
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);
  const [bookErr, setBookErr] = useState('');
  const [pickerKey, setPickerKey] = useState(0);

  useEffect(() => { api(`/doctors/${id}`).then((d) => setDoctor(d.doctor)).catch((e) => setError(e.message)); }, [id]);

  async function confirm() {
    setBusy(true);
    setBookErr('');
    try {
      const d = await api('/appointments', { method: 'POST', body: { doctorId: id, date: pick.date, time: pick.time, reason } });
      setDone(d.appointment);
    } catch (e) {
      setBookErr(e.message);
      setPick(null);
      setPickerKey((k) => k + 1); // reload slots (someone may have just taken it)
    } finally {
      setBusy(false);
    }
  }

  if (error) return <main className="main"><p className="error">{error}</p></main>;
  if (!doctor) return <main className="main"><div className="spinner" /></main>;
  const h = doctor.hospital;

  if (done) {
    return (
      <main className="main narrow">
        <div className="success-card">
          <div className="tick">✓</div>
          <h2>Appointment confirmed</h2>
          <p className="muted">Booking reference <b>#{done._id.slice(-6).toUpperCase()}</b></p>
          <dl>
            <dt>Doctor</dt><dd>{done.doctor.name} · {done.doctor.specialization}</dd>
            <dt>Hospital</dt><dd>{done.hospital.name}, {done.hospital.area}</dd>
            <dt>Date</dt><dd>{fmtDate(done.date)}</dd>
            <dt>Time</dt><dd>{fmtTime(done.time)}</dd>
            <dt>Fee</dt><dd>₹{done.doctor.fee} (pay at the hospital)</dd>
          </dl>
          <p className="muted small">Please arrive 15 minutes early and carry previous reports. You can reschedule or cancel from “My appointments”.</p>
          <div className="row-actions center">
            <Link className="primary" to="/appointments">View my appointments</Link>
            <Link className="secondary" to="/">Back to home</Link>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="main">
      <Link className="back" to={`/hospitals/${h._id}`}>← {h.name}</Link>
      <div className="doc-layout">
        <section className="panel">
          <div className="doc-head">
            <Avatar name={doctor.name} gender={doctor.gender} size={88} />
            <div>
              <h2>{doctor.name}</h2>
              <div className="specialty">{doctor.specialization}</div>
              <div className="muted">{doctor.qualification}</div>
            </div>
          </div>
          <div className="info-grid two">
            <div className="info-card"><small>Experience</small><b>{doctor.experienceYears} years</b></div>
            <div className="info-card"><small>Consultation fee</small><b>₹{doctor.fee}</b></div>
            <div className="info-card"><small>Languages</small><b>{(doctor.languages || []).join(', ') || '—'}</b></div>
            <div className="info-card"><small>Slot length</small><b>{doctor.slotMinutes} minutes</b></div>
          </div>
          <p>{doctor.about}</p>
          <h4>Hospital</h4>
          <p><Link to={`/hospitals/${h._id}`}><b>{h.name}</b></Link><br /><span className="muted">{h.address}</span><br />
            <a href={directionsLink(h)} target="_blank" rel="noopener noreferrer">Get directions ↗</a></p>
          <h4>Working hours</h4>
          <p className="muted">{scheduleText(doctor.schedule)}</p>
        </section>

        <section className="panel">
          <h3>Book an appointment</h3>
          {bookErr && <p className="error">{bookErr}</p>}
          <SlotPicker key={pickerKey} doctor={doctor} value={pick} onChange={setPick} />
          <label className="field">Reason for visit (optional)
            <textarea value={reason} onChange={(e) => setReason(e.target.value)} maxLength={300} rows={2} placeholder="e.g. cough for 2 weeks" />
          </label>
          {pick && <div className="summary">Selected: <b>{fmtDate(pick.date)}</b> at <b>{fmtTime(pick.time)}</b></div>}
          <button className="primary block" disabled={!pick || busy} onClick={confirm}>
            {busy ? 'Booking…' : pick ? 'Confirm appointment' : 'Select a time slot'}
          </button>
        </section>
      </div>
    </main>
  );
}
