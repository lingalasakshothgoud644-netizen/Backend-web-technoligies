import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../context/AppContext.jsx';
import SlotPicker from '../components/SlotPicker.jsx';
import { fmtDate, fmtTime, ymd } from '../utils';

export default function MyAppointments() {
  const { notify } = useApp();
  const [list, setList] = useState(null);
  const [error, setError] = useState('');
  const [resched, setResched] = useState(null); // { appt, pick, doctor }
  const [busy, setBusy] = useState(false);

  const load = () => api('/appointments').then((d) => setList(d.appointments)).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  const now = new Date();
  const isUpcoming = (a) => a.status === 'booked' && `${a.date}T${a.time}` >= `${ymd(now)}T${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  async function cancel(a) {
    if (!window.confirm(`Cancel your appointment with ${a.doctor.name} on ${fmtDate(a.date)} at ${fmtTime(a.time)}?`)) return;
    try { await api(`/appointments/${a._id}`, { method: 'PUT', body: { status: 'cancelled' } }); notify('Appointment cancelled'); load(); }
    catch (e) { notify(e.message); }
  }

  async function openResched(a) {
    try {
      const d = await api(`/doctors/${a.doctor._id}`);
      setResched({ appt: a, doctor: d.doctor, pick: null });
    } catch (e) { notify(e.message); }
  }

  async function saveResched() {
    setBusy(true);
    try {
      await api(`/appointments/${resched.appt._id}`, { method: 'PUT', body: resched.pick });
      notify('Appointment rescheduled');
      setResched(null);
      load();
    } catch (e) { notify(e.message); } finally { setBusy(false); }
  }

  if (error) return <main className="main"><p className="error">{error}</p></main>;
  if (!list) return <main className="main"><div className="spinner" /></main>;

  const upcoming = list.filter(isUpcoming);
  const past = list.filter((a) => !isUpcoming(a)).reverse();

  const Row = ({ a, actions }) => (
    <article className="appt">
      <div className="appt-date"><b>{new Date(`${a.date}T00:00:00`).getDate()}</b><small>{new Date(`${a.date}T00:00:00`).toLocaleString('en-IN', { month: 'short' })}</small></div>
      <div className="appt-main">
        <h3>{a.doctor.name} <span className="specialty">{a.doctor.specialization}</span></h3>
        <div className="muted">{a.hospital.name}, {a.hospital.area}</div>
        <div className="muted small">{fmtDate(a.date)} · {fmtTime(a.time)}{a.reason ? ` · “${a.reason}”` : ''}</div>
      </div>
      <div className="appt-side">
        <span className={`status ${a.status}`}>{a.status}</span>
        {actions}
      </div>
    </article>
  );

  return (
    <main className="main narrow">
      <div className="section-head"><div><h2>My appointments</h2><p>Upcoming visits can be rescheduled or cancelled.</p></div><Link className="primary" to="/search">+ Book new</Link></div>

      <h3 className="sub">Upcoming</h3>
      {upcoming.length === 0 && <div className="empty">No upcoming appointments. <Link to="/search">Find a doctor</Link></div>}
      {upcoming.map((a) => (
        <Row key={a._id} a={a} actions={<div className="btnrow"><button className="secondary sm" onClick={() => openResched(a)}>Reschedule</button><button className="danger sm" onClick={() => cancel(a)}>Cancel</button></div>} />
      ))}

      {past.length > 0 && <h3 className="sub">Past & cancelled</h3>}
      {past.map((a) => <Row key={a._id} a={a} />)}

      {resched && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setResched(null)}>
          <div className="modal">
            <h3>Reschedule with {resched.doctor.name}</h3>
            <p className="muted small">Current: {fmtDate(resched.appt.date)} at {fmtTime(resched.appt.time)}</p>
            <SlotPicker doctor={resched.doctor} value={resched.pick} onChange={(pick) => setResched({ ...resched, pick })} />
            <div className="btnrow end">
              <button className="secondary" onClick={() => setResched(null)}>Close</button>
              <button className="primary" disabled={!resched.pick || busy} onClick={saveResched}>{busy ? 'Saving…' : 'Save new time'}</button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
