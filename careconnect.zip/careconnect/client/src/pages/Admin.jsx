import { useEffect, useState } from 'react';
import { api } from '../api';
import { useApp } from '../context/AppContext.jsx';
import { fmtDate, fmtTime } from '../utils';

const MON_SAT = [1, 2, 3, 4, 5, 6];
const SCHEDULES = {
  'Mon–Sat · 9–1 & 4–7': [{ days: MON_SAT, start: '09:00', end: '13:00' }, { days: MON_SAT, start: '16:00', end: '19:00' }],
  'Mon–Fri · 10–2 & 5–8': [{ days: [1, 2, 3, 4, 5], start: '10:00', end: '14:00' }, { days: [1, 2, 3, 4, 5], start: '17:00', end: '20:00' }],
  'Mon–Sat · 11–5': [{ days: MON_SAT, start: '11:00', end: '17:00' }],
};
const emptyHospital = { name: '', logoText: '', type: 'Hospital', area: '', address: '', lat: '', lng: '', phone: '', website: '', image: '', timings: 'Open 24 hours', emergency: false, color: '#1769aa' };
const emptyDoctor = { name: '', specialization: '', hospital: '', qualification: '', experienceYears: 5, fee: 500, schedule: Object.keys(SCHEDULES)[0], loginEmail: '', loginPassword: '' };

export default function Admin() {
  const { notify } = useApp();
  const [tab, setTab] = useState('overview');
  const [stats, setStats] = useState(null);
  const [hospitals, setHospitals] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [appts, setAppts] = useState([]);
  const [specs, setSpecs] = useState([]);
  const [hForm, setHForm] = useState(null); // hospital being added/edited
  const [dForm, setDForm] = useState(null);

  const loadAll = () => {
    api('/admin/stats').then(setStats).catch((e) => notify(e.message));
    api('/hospitals').then((d) => setHospitals(d.hospitals));
    api('/doctors').then((d) => setDoctors(d.doctors));
    api('/appointments').then((d) => setAppts(d.appointments));
    api('/doctors/meta/specialties').then((d) => setSpecs(d.specialties));
  };
  useEffect(loadAll, []); // eslint-disable-line

  const run = async (fn, okMsg) => {
    try { await fn(); notify(okMsg); loadAll(); } catch (e) { notify(e.message); }
  };

  // ---- hospitals ----
  const saveHospital = (e) => {
    e.preventDefault();
    const body = { ...hForm, lat: Number(hForm.lat), lng: Number(hForm.lng) };
    run(async () => {
      if (hForm._id) await api(`/hospitals/${hForm._id}`, { method: 'PUT', body });
      else await api('/hospitals', { method: 'POST', body });
      setHForm(null);
    }, 'Hospital saved');
  };
  const delHospital = (h) => window.confirm(`Delete ${h.name}?`) && run(() => api(`/hospitals/${h._id}`, { method: 'DELETE' }), 'Hospital deleted');

  // ---- doctors ----
  const saveDoctor = (e) => {
    e.preventDefault();
    const body = { ...dForm, experienceYears: Number(dForm.experienceYears), fee: Number(dForm.fee), schedule: typeof dForm.schedule === 'string' ? SCHEDULES[dForm.schedule] : dForm.schedule, department: dForm.specialization };
    if (!dForm._id) body.gender = 'M';
    run(async () => {
      if (dForm._id) await api(`/doctors/${dForm._id}`, { method: 'PUT', body });
      else await api('/doctors', { method: 'POST', body });
      setDForm(null);
    }, 'Doctor saved');
  };
  const delDoctor = (d) => window.confirm(`Delete ${d.name}?`) && run(() => api(`/doctors/${d._id}`, { method: 'DELETE' }), 'Doctor deleted');

  const setAppt = (a, status) => run(() => api(`/appointments/${a._id}`, { method: 'PUT', body: { status } }), `Marked ${status}`);
  const delAppt = (a) => window.confirm('Permanently delete this record?') && run(() => api(`/appointments/${a._id}`, { method: 'DELETE' }), 'Record deleted');

  const field = (form, setForm, key, label, props = {}) => (
    <label>{label}<input value={form[key] ?? ''} onChange={(e) => setForm({ ...form, [key]: e.target.value })} {...props} /></label>
  );

  return (
    <main className="main">
      <div className="section-head"><div><h2>Admin panel</h2><p>Manage hospitals, doctors and appointments.</p></div></div>
      <div className="tabs">
        {[['overview', 'Overview'], ['hospitals', 'Hospitals'], ['doctors', 'Doctors'], ['appointments', 'Appointments']].map(([k, l]) => (
          <button key={k} className={tab === k ? 'active' : ''} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>

      {tab === 'overview' && stats && (
        <>
          <div className="stats">
            <div className="stat"><b>{stats.hospitals}</b><small>Hospitals & clinics</small></div>
            <div className="stat"><b>{stats.doctors}</b><small>Doctors</small></div>
            <div className="stat"><b>{stats.patients}</b><small>Patients</small></div>
            <div className="stat"><b>{stats.upcoming}</b><small>Upcoming appointments</small></div>
            <div className="stat"><b>{stats.appointments.completed || 0}</b><small>Completed</small></div>
            <div className="stat"><b>{stats.appointments.cancelled || 0}</b><small>Cancelled</small></div>
          </div>
          <h3 className="sub">Most booked departments</h3>
          {stats.topDepartments.length === 0 ? <div className="empty">No bookings yet.</div> : (
            <div className="table-wrap"><table><tbody>{stats.topDepartments.map((d) => <tr key={d.department}><td>{d.department}</td><td>{d.count} appointments</td></tr>)}</tbody></table></div>
          )}
        </>
      )}

      {tab === 'hospitals' && (
        <>
          <button className="primary" onClick={() => setHForm({ ...emptyHospital })}>+ Add hospital / clinic</button>
          <div className="table-wrap"><table>
            <thead><tr><th>Name</th><th>Type</th><th>Area</th><th>Doctors</th><th /></tr></thead>
            <tbody>{hospitals.map((h) => (
              <tr key={h._id}><td><b>{h.name}</b></td><td>{h.type}</td><td>{h.area}</td><td>{h.doctorCount}</td>
                <td className="nowrap"><button className="secondary sm" onClick={() => setHForm({ ...h })}>Edit</button> <button className="danger sm" onClick={() => delHospital(h)}>Delete</button></td></tr>
            ))}</tbody>
          </table></div>
        </>
      )}

      {tab === 'doctors' && (
        <>
          <button className="primary" onClick={() => setDForm({ ...emptyDoctor, hospital: hospitals[0]?._id || '', specialization: specs[0] || '' })}>+ Add doctor</button>
          <div className="table-wrap"><table>
            <thead><tr><th>Doctor</th><th>Specialty</th><th>Hospital</th><th>Exp.</th><th>Fee</th><th /></tr></thead>
            <tbody>{doctors.map((d) => (
              <tr key={d._id}><td><b>{d.name}</b></td><td>{d.specialization}</td><td>{d.hospital?.name}</td><td>{d.experienceYears} y</td><td>₹{d.fee}</td>
                <td className="nowrap"><button className="secondary sm" onClick={() => setDForm({ ...d, hospital: d.hospital._id })}>Edit</button> <button className="danger sm" onClick={() => delDoctor(d)}>Delete</button></td></tr>
            ))}</tbody>
          </table></div>
        </>
      )}

      {tab === 'appointments' && (
        <div className="table-wrap"><table>
          <thead><tr><th>Date</th><th>Time</th><th>Patient</th><th>Doctor</th><th>Hospital</th><th>Status</th><th /></tr></thead>
          <tbody>{appts.map((a) => (
            <tr key={a._id}><td>{fmtDate(a.date)}</td><td>{fmtTime(a.time)}</td><td>{a.patient?.name}</td><td>{a.doctor?.name}</td><td>{a.hospital?.name}</td>
              <td><span className={`status ${a.status}`}>{a.status}</span></td>
              <td className="nowrap">
                {a.status === 'booked' && <><button className="primary sm" onClick={() => setAppt(a, 'completed')}>Complete</button> <button className="secondary sm" onClick={() => setAppt(a, 'cancelled')}>Cancel</button> </>}
                <button className="danger sm" onClick={() => delAppt(a)}>Delete</button></td></tr>
          ))}</tbody>
        </table>{appts.length === 0 && <div className="empty">No appointments yet.</div>}</div>
      )}

      {hForm && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setHForm(null)}>
          <form className="modal" onSubmit={saveHospital}>
            <h3>{hForm._id ? 'Edit' : 'Add'} hospital / clinic</h3>
            <div className="formgrid">
              {field(hForm, setHForm, 'name', 'Name', { required: true })}
              {field(hForm, setHForm, 'logoText', 'Short name on banner')}
              <label>Type<select value={hForm.type} onChange={(e) => setHForm({ ...hForm, type: e.target.value })}><option>Hospital</option><option>Clinic</option><option>Dental</option></select></label>
              {field(hForm, setHForm, 'area', 'Area', { required: true })}
              {field(hForm, setHForm, 'address', 'Address', { required: true })}
              {field(hForm, setHForm, 'lat', 'Latitude', { required: true, type: 'number', step: 'any' })}
              {field(hForm, setHForm, 'lng', 'Longitude', { required: true, type: 'number', step: 'any' })}
              {field(hForm, setHForm, 'phone', 'Phone')}
              {field(hForm, setHForm, 'website', 'Website')}
              {field(hForm, setHForm, 'image', 'Image URL')}
              {field(hForm, setHForm, 'timings', 'Timings')}
              {field(hForm, setHForm, 'color', 'Brand colour', { type: 'color' })}
              <label className="check"><input type="checkbox" checked={!!hForm.emergency} onChange={(e) => setHForm({ ...hForm, emergency: e.target.checked })} /> 24×7 emergency</label>
            </div>
            <div className="btnrow end"><button type="button" className="secondary" onClick={() => setHForm(null)}>Cancel</button><button className="primary">Save</button></div>
          </form>
        </div>
      )}

      {dForm && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setDForm(null)}>
          <form className="modal" onSubmit={saveDoctor}>
            <h3>{dForm._id ? 'Edit' : 'Add'} doctor</h3>
            <div className="formgrid">
              {field(dForm, setDForm, 'name', 'Name (e.g. Dr. A Rao)', { required: true })}
              <label>Specialty<select value={dForm.specialization} onChange={(e) => setDForm({ ...dForm, specialization: e.target.value })}>{specs.map((s) => <option key={s}>{s}</option>)}</select></label>
              <label>Hospital<select value={dForm.hospital} onChange={(e) => setDForm({ ...dForm, hospital: e.target.value })} required>{hospitals.map((h) => <option key={h._id} value={h._id}>{h.name}</option>)}</select></label>
              {field(dForm, setDForm, 'qualification', 'Qualification')}
              {field(dForm, setDForm, 'experienceYears', 'Experience (years)', { type: 'number', min: 0 })}
              {field(dForm, setDForm, 'fee', 'Fee (₹)', { type: 'number', min: 0 })}
              {!dForm._id && (
                <label>Working hours<select value={dForm.schedule} onChange={(e) => setDForm({ ...dForm, schedule: e.target.value })}>{Object.keys(SCHEDULES).map((s) => <option key={s}>{s}</option>)}</select></label>
              )}
              {!dForm._id && field(dForm, setDForm, 'loginEmail', 'Login email (optional)', { type: 'email' })}
              {!dForm._id && field(dForm, setDForm, 'loginPassword', 'Login password (optional)', { minLength: 6 })}
            </div>
            <div className="btnrow end"><button type="button" className="secondary" onClick={() => setDForm(null)}>Cancel</button><button className="primary">Save</button></div>
          </form>
        </div>
      )}
    </main>
  );
}
