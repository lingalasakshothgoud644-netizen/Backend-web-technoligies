import { useState } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../context/AppContext.jsx';

export default function Login() {
  const { user, login } = useApp();
  const nav = useNavigate();
  const from = useLocation().state?.from || '/';
  const [mode, setMode] = useState('login');
  const [f, setF] = useState({ name: '', email: '', phone: '', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  if (user) return <Navigate to={from} replace />;

  async function submit(e) {
    e.preventDefault();
    setErr('');
    setBusy(true);
    try {
      const d = await api(mode === 'login' ? '/auth/login' : '/auth/register', { method: 'POST', body: f });
      login(d.token, d.user);
      nav(from, { replace: true });
    } catch (e2) {
      setErr(e2.message);
    } finally {
      setBusy(false);
    }
  }

  const demo = (email, password) => setF({ ...f, email, password });

  return (
    <div className="login-page">
      <div className="login-side">
        <div className="brand light"><span className="brandmark">✚</span>CareConnect</div>
        <h1>Find the right doctor.<br />Book in a few taps.</h1>
        <ul>
          <li>📍 Hospitals & clinics near your location</li>
          <li>🔎 Search pulmonologist, dentist, cardiologist…</li>
          <li>🤖 Care Assistant suggests the right doctor for your symptoms</li>
          <li>🗓 Pick a free time slot and confirm instantly</li>
        </ul>
      </div>
      <form className="login-card" onSubmit={submit}>
        <img src="/assets/chatbot-logo.jpeg" alt="" className="login-logo" />
        <h2>{mode === 'login' ? 'Welcome back' : 'Create your patient account'}</h2>
        <p className="muted">Please sign in first - we use your location to show nearby hospitals.</p>

        {mode === 'register' && (
          <>
            <label>Full name<input value={f.name} onChange={set('name')} required placeholder="Your full name" /></label>
            <label>Phone (optional)<input value={f.phone} onChange={set('phone')} placeholder="10-digit mobile number" inputMode="tel" /></label>
          </>
        )}
        <label>Email<input type="email" value={f.email} onChange={set('email')} required placeholder="you@example.com" autoComplete="email" /></label>
        <label>Password<input type="password" value={f.password} onChange={set('password')} required minLength={6} placeholder="At least 6 characters" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} /></label>

        {err && <p className="error">{err}</p>}
        <button className="primary block" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}</button>
        <p className="switch">
          {mode === 'login' ? 'New to CareConnect?' : 'Already have an account?'}{' '}
          <button type="button" className="link" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setErr(''); }}>
            {mode === 'login' ? 'Create an account' : 'Sign in'}
          </button>
        </p>

        {mode === 'login' && (
          <div className="demo-box">
            <b>Demo accounts</b> <span className="muted small">(click to fill)</span>
            <div>
              <button type="button" onClick={() => demo('patient@careconnect.test', 'Patient@123')}>Patient</button>
              <button type="button" onClick={() => demo('ananya.kumar@careconnect.test', 'Doctor@123')}>Doctor</button>
              <button type="button" onClick={() => demo('admin@careconnect.test', 'Admin@123')}>Admin</button>
            </div>
          </div>
        )}
      </form>
    </div>
  );
}
