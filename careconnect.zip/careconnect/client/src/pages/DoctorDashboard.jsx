import { useEffect, useState } from 'react';
import { api } from '../api';
import { useApp } from '../context/AppContext.jsx';
import { fmtDate, fmtTime, ymd } from '../utils';

// Doctor role: sees only their own appointments and can complete / cancel them
export default function DoctorDashboard() {
  const { notify } = useApp();
  const [list, setList] = useState(null);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('upcoming');

  const load = () => api('/appointments').then((d) => setList(d.appointments)).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  async function setStatus(a, status) {
    try { await api(`/appointments/${a._id}`, { method: 'PUT', body: { status } }); notify(`Marked ${status}`); load(); }
    catch (e) { notify(e.message); }
  }

  if (error) return <main className="main"><p className="error">{error}</p></main>;
  if (!list) return <main className="main"><div className="spinner" /></main>;

  const today = ymd(new Date());
  const rows = list.filter((a) => (filter === 'today' ? a.date === today && a.status === 'booked' : filter === 'upcoming' ? a.status === 'booked' && a.date >= today : filter === 'all' ? true : a.status === filter));
  const todayCount = list.filter((a) => a.date === today && a.status === 'booked').length;

  return (
    <main className="main">
      <div className="section-head"><div><h2>My schedule</h2><p>Appointments booked with you by patients.</p></div></div>
      <div className="stats">
        <div className="stat"><b>{todayCount}</b><small>Today</small></div>
        <div className="stat"><b>{list.filter((a) => a.status === 'booked' && a.date >= today).length}</b><small>Upcoming</small></div>
        <div className="stat"><b>{list.filter((a) => a.status === 'completed').length}</b><small>Completed</small></div>
      </div>
      <div className="tabs">
        {['upcoming', 'today', 'completed', 'cancelled', 'all'].map((f) => (
          <button key={f} className={filter === f ? 'active' : ''} onClick={() => setFilter(f)}>{f[0].toUpperCase() + f.slice(1)}</button>
        ))}
      </div>
      {rows.length === 0 ? <div className="empty">No appointments here.</div> : (
        <div className="table-wrap">
          <table>
            <thead><tr><th>Date</th><th>Time</th><th>Patient</th><th>Contact</th><th>Reason</th><th>Status</th><th /></tr></thead>
            <tbody>
              {rows.map((a) => (
                <tr key={a._id}>
                  <td>{fmtDate(a.date)}</td><td>{fmtTime(a.time)}</td>
                  <td><b>{a.patient?.name}</b></td><td>{a.patient?.phone || a.patient?.email}</td>
                  <td>{a.reason || '—'}</td>
                  <td><span className={`status ${a.status}`}>{a.status}</span></td>
                  <td className="nowrap">
                    {a.status === 'booked' && (
                      <>
                        <button className="primary sm" onClick={() => setStatus(a, 'completed')}>Complete</button>{' '}
                        <button className="danger sm" onClick={() => setStatus(a, 'cancelled')}>Cancel</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}
