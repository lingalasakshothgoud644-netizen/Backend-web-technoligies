import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../context/AppContext.jsx';
import HospitalCard from '../components/HospitalCard.jsx';
import DoctorCard from '../components/DoctorCard.jsx';

export default function Search() {
  const { coords } = useApp();
  const [params, setParams] = useSearchParams();
  const q = params.get('q') || '';
  const tab = params.get('tab') || (q ? 'doctors' : 'doctors');
  const [text, setText] = useState(q);
  const [type, setType] = useState('All');
  const [specialty, setSpecialty] = useState('All');
  const [specialties, setSpecialties] = useState([]);
  const [doctors, setDoctors] = useState(null);
  const [hospitals, setHospitals] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => { setText(q); }, [q]);
  useEffect(() => { api('/doctors/meta/specialties').then((d) => setSpecialties(d.specialties)).catch(() => {}); }, []);

  useEffect(() => {
    setError('');
    setDoctors(null);
    setHospitals(null);
    const base = { q, lat: coords.lat, lng: coords.lng };
    api('/doctors', { params: { ...base, specialty } }).then((d) => setDoctors(d.doctors)).catch((e) => setError(e.message));
    api('/hospitals', { params: { ...base, type, specialty } }).then((d) => setHospitals(d.hospitals)).catch((e) => setError(e.message));
  }, [q, type, specialty, coords.lat, coords.lng]);

  const setTab = (t) => { const p = new URLSearchParams(params); p.set('tab', t); setParams(p, { replace: true }); };
  const submit = (e) => {
    e.preventDefault();
    const p = new URLSearchParams(params);
    if (text.trim()) p.set('q', text.trim()); else p.delete('q');
    setParams(p);
  };

  return (
    <main className="main">
      <form className="searchbox on-page" onSubmit={submit}>
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Search pulmonologist, dentist, doctor name, hospital or area" aria-label="Search" />
        <button className="primary">⌕ Search</button>
        {q && <button type="button" className="secondary" onClick={() => { setText(''); setParams({}); }}>Clear</button>}
      </form>

      <div className="filters">
        <select value={specialty} onChange={(e) => setSpecialty(e.target.value)} aria-label="Specialty">
          <option value="All">All specialties</option>
          {specialties.map((s) => <option key={s}>{s}</option>)}
        </select>
        <select value={type} onChange={(e) => setType(e.target.value)} aria-label="Facility type">
          {['All', 'Hospital', 'Clinic', 'Dental'].map((t) => <option key={t} value={t}>{t === 'All' ? 'All facility types' : t === 'Dental' ? 'Dental clinics' : t + 's'}</option>)}
        </select>
        <span className="muted small">Sorted by distance from {coords.label}</span>
      </div>

      <div className="tabs">
        <button className={tab === 'doctors' ? 'active' : ''} onClick={() => setTab('doctors')}>Doctors {doctors && `(${doctors.length})`}</button>
        <button className={tab === 'hospitals' ? 'active' : ''} onClick={() => setTab('hospitals')}>Hospitals & clinics {hospitals && `(${hospitals.length})`}</button>
      </div>

      {error && <p className="error">{error}</p>}

      {tab === 'doctors' ? (
        !doctors ? <div className="spinner" /> :
        doctors.length === 0 ? <div className="empty">No doctors match “{q}”. Try “lung”, “dentist”, “heart” or a hospital name.</div> :
        <div className="doctors">{doctors.map((d) => <DoctorCard key={d._id} d={d} />)}</div>
      ) : (
        !hospitals ? <div className="spinner" /> :
        hospitals.length === 0 ? <div className="empty">No hospitals match your search or filters.</div> :
        <div className="hospital-grid">{hospitals.map((h) => <HospitalCard key={h._id} h={h} />)}</div>
      )}
    </main>
  );
}
