import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../context/AppContext.jsx';
import HospitalCard from '../components/HospitalCard.jsx';
import DoctorCard from '../components/DoctorCard.jsx';
import { SPECIALTY_ICONS } from '../utils';

const QUICK = ['Pulmonologist', 'Dentist', 'Cardiologist', 'Dermatologist', 'Pediatrician', 'Gynecologist', 'Orthopedic', 'General Physician', 'ENT Specialist', 'Ophthalmologist'];

export default function Home() {
  const { user, coords, locStatus, detectLocation } = useApp();
  const nav = useNavigate();
  const [q, setQ] = useState('');
  const [hospitals, setHospitals] = useState(null);
  const [doctors, setDoctors] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    setError('');
    Promise.all([
      api('/hospitals', { params: { lat: coords.lat, lng: coords.lng, limit: 6 } }),
      api('/doctors', { params: { lat: coords.lat, lng: coords.lng, limit: 6 } }),
    ])
      .then(([h, d]) => { setHospitals(h.hospitals); setDoctors(d.doctors); })
      .catch((e) => setError(e.message));
  }, [coords.lat, coords.lng]);

  const go = (text) => nav(`/search?q=${encodeURIComponent(text)}`);
  const locText = {
    idle: 'Showing hospitals around central Hyderabad.',
    asking: 'Asking your browser for permission…',
    granted: 'Showing hospitals nearest to your current location.',
    denied: 'Location permission denied - showing central Hyderabad. You can still search by area.',
    unsupported: 'Your browser can’t share location - showing central Hyderabad.',
  }[locStatus];

  return (
    <>
      <section className="hero">
        <div className="hero-inner">
          <div>
            <div className="eyebrow">✦ Hi {user.name.split(' ')[0]}, how can we help?</div>
            <h1>Find the right care.<br /><em>Right when you need it.</em></h1>
            <p>Search specialists, see nearby hospitals and clinics, and book an appointment time that suits you.</p>
            <form className="searchbox" onSubmit={(e) => { e.preventDefault(); if (q.trim()) go(q.trim()); }}>
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Try “pulmonologist”, “dentist”, “heart”, or a hospital name" aria-label="Search doctors, specialties and hospitals" />
              <button className="primary">⌕ Search</button>
            </form>
            <div className="locline">
              <button className="link" onClick={detectLocation}>⌖ {locStatus === 'granted' ? 'Update my location' : 'Use my location'}</button>
              <span> · {locText}</span>
            </div>
          </div>
          <div className="hero-art">
            <img src="/assets/chatbot-logo.jpeg" alt="Care assistant" />
            <div className="floatcard f1">🤖 Not sure which doctor?<strong>Ask the Care Assistant</strong></div>
            <div className="floatcard f2">✓ Free slots shown live<strong>Book in seconds</strong></div>
          </div>
        </div>
      </section>

      <main className="main">
        <div className="section-head"><div><h2>Browse by specialty</h2><p>Tap a specialty to see doctors and hospitals.</p></div></div>
        <div className="specgrid">
          {QUICK.map((s) => (
            <button key={s} className="spec" onClick={() => go(s)}><span>{SPECIALTY_ICONS[s]}</span>{s}</button>
          ))}
        </div>

        {error && <p className="error">{error}</p>}

        <div className="section-head">
          <div><h2>Hospitals & clinics near you</h2><p>Sorted by distance from {coords.label}.</p></div>
          <Link className="secondary" to="/search?tab=hospitals">See all 17 →</Link>
        </div>
        {!hospitals ? <div className="spinner" /> : <div className="hospital-grid">{hospitals.map((h) => <HospitalCard key={h._id} h={h} />)}</div>}

        <div className="section-head">
          <div><h2>Doctors near you</h2><p>Sample doctor profiles for the project demo.</p></div>
          <Link className="secondary" to="/search">Find more →</Link>
        </div>
        {!doctors ? <div className="spinner" /> : <div className="doctors">{doctors.map((d) => <DoctorCard key={d._id} d={d} />)}</div>}

        <div className="section-head"><div><h2>Care in three simple steps</h2></div></div>
        <div className="steps">
          <div className="step"><span>1</span><b>Find care</b><small>Search a specialty or ask the Care Assistant about your symptoms.</small></div>
          <div className="step"><span>2</span><b>Pick a slot</b><small>See the doctor’s experience, hospital and free time slots.</small></div>
          <div className="step"><span>3</span><b>Get confirmed</b><small>Review your booking and manage it under “My appointments”.</small></div>
        </div>
      </main>
    </>
  );
}
