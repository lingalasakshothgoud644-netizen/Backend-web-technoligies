# CareConnect — MERN Doctor Appointment Booking

A student-project starter with a React + Vite frontend, Express REST API, MongoDB/Mongoose models, JWT authentication, role-based admin routes, doctor/hospital search, slot listing, booking/cancellation/rescheduling, and a safely bounded AI chat endpoint.

## Requirements
- Node.js 20+ (LTS recommended)
- MongoDB local instance or MongoDB Atlas URI
- Optional: OpenAI-compatible API key for AI chat

## Run locally
Open two terminals.

### 1) Backend
```bash
cd server
cp .env.example .env
# Edit .env and set MONGO_URI and JWT_SECRET. Set AI_API_KEY only if using AI chat.
npm install
npm run seed
npm run dev
```
API runs on `http://localhost:5000`. The seed script inserts clearly labelled demo data and does not claim live appointment availability.

### 2) Frontend
```bash
cd client
npm install
npm run dev
```
Open the Vite URL printed in the terminal (usually `http://localhost:5173`).

## Demo admin
Set `SEED_ADMIN_EMAIL` and `SEED_ADMIN_PASSWORD` in `server/.env` before `npm run seed`. The seed script creates an admin account using those values. Change the password before any shared or deployed use.

## AI chat
The chat endpoint is `POST /api/chat` with `{ "message": "..." }` and a logged-in user's bearer token. Configure `AI_API_KEY`, `AI_BASE_URL` (OpenAI-compatible endpoint), and `AI_MODEL` in the server environment. If no key is configured, the API uses a small safety-oriented rule-based fallback and clearly identifies it as such. Never treat the chatbot as a diagnosis or prescription service.

## Location
The browser asks for geolocation only after the patient clicks the location control. The backend can sort facilities by stored coordinates using a Haversine distance calculation. Accurate distance results require verified coordinates. If location is denied, area search remains available.

## Data accuracy and safety
- Hospital seed records include real facility names and official reference links where known, but verify addresses, images, phone numbers, departments, clinician credentials, prices, opening hours and appointment slots before real-world use.
- Seed doctors and schedules are illustrative demo records, not claims about real clinicians or actual appointment availability.
- Do not store real patient health information in a class demo. Add HTTPS, rate limiting, secure secrets management, logging controls, consent, data retention rules and applicable privacy/legal review before deployment.
- Booking routes re-check availability and use a unique index to prevent duplicate doctor/time bookings. For production-grade concurrency, use a MongoDB replica set transaction or a carefully tested atomic slot-inventory design.
