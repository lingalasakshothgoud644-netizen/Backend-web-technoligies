import jwt from 'jsonwebtoken';
import { User } from './models.js';
export async function requireAuth(req,res,next){try{const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');if(!token)return res.status(401).json({message:'Please log in.'});const payload=jwt.verify(token,process.env.JWT_SECRET);req.user=await User.findById(payload.sub).select('-passwordHash');if(!req.user)return res.status(401).json({message:'Account not found.'});next()}catch{return res.status(401).json({message:'Session expired. Please log in again.'})}}
export function requireRole(...roles){return (req,res,next)=>roles.includes(req.user?.role)?next():res.status(403).json({message:'You do not have permission for this action.'})}
export function asyncRoute(fn){return (req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next)}
export function distanceKm(a,b){const rad=x=>x*Math.PI/180;const dLat=rad(b.lat-a.lat),dLng=rad(b.lng-a.lng);const h=Math.sin(dLat/2)**2+Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(dLng/2)**2;return 6371*2*Math.atan2(Math.sqrt(h),Math.sqrt(1-h))}
