import 'dotenv/config';import mongoose from 'mongoose';import bcrypt from 'bcryptjs';import {Hospital,Doctor,Schedule,User} from './models.js';
const facilities=[
['Apollo Health City','Jubilee Hills','Road No. 72, Film Nagar, Jubilee Hills, Hyderabad','https://www.apollohospitals.com/region/hyderabad/our-centres/',['Multispecialty','Cardiology','Pulmonology']],
['KIMS Hospitals','Secunderabad','Minister Road, Secunderabad, Hyderabad','https://www.kimshospitals.com/',['Multispecialty','Cardiology']],
['Yashoda Hospitals','HITEC City','Kothaguda, HITEC City, Hyderabad','https://www.yashodahospitals.com/locations/',['Multispecialty','Cardiology','Pulmonology']],
['CARE Hospitals','Banjara Hills','Banjara Hills, Hyderabad','https://www.carehospitals.com/',['Multispecialty','Cardiology']],
['Continental Hospitals','Gachibowli','Plot No. 3, Road No. 2, Financial District, Nanakramguda, Hyderabad','https://continentalhospitals.com/our-location/',['Multispecialty','Cardiology','Pulmonology']],
['AIG Hospitals','Gachibowli','Gachibowli, Hyderabad','https://www.aighospitals.com/',['Multispecialty']],
['Rainbow Children’s Hospital','Banjara Hills','Banjara Hills, Hyderabad','https://www.rainbowhospitals.in/',['Children']],
['Fernandez Hospital','Hyderabad','Hyderabad, Telangana','https://www.fernandez.foundation/',["Women's health"]],
['Sunshine Hospitals','Secunderabad','Secunderabad, Hyderabad','https://www.sunshinehospitals.com/',['Multispecialty']],
['Medicover Hospitals','HITEC City','HITEC City, Hyderabad','https://www.medicoverhospitals.in/',['Multispecialty']],
['Gleneagles Hospitals','Somajiguda','Hyderabad, Telangana','https://www.gleneagleshospitals.co.in/',['Multispecialty']],
['Kamineni Hospitals','Malakpet','Malakpet, Hyderabad','https://www.kaminenihospitals.com/',['Multispecialty']],
["Nizam's Institute of Medical Sciences (NIMS)",'Punjagutta','Punjagutta, Hyderabad','https://nims.edu.in/',['Multispecialty','Cardiology']],
['National Dental Care','Punjagutta','Srinagar Colony Main Road, Hyderabad','https://www.google.com/maps/search/?api=1&query=National+Dental+Care+Srinagar+Colony+Hyderabad',['Dental']],
['Metrocare Clinics','Habsiguda','Vijayanagar Colony, Habsiguda, Hyderabad','https://www.google.com/maps/search/?api=1&query=Metrocare+Clinics+Habsiguda',['Multispecialty']],
['Yuti Clinics','Kondapur','Masjid Banda, Botanical Garden Road, Kondapur, Hyderabad','https://www.google.com/maps/search/?api=1&query=Yuti+Clinics+Kondapur',['Multispecialty']],
['Ameerpet Dental Hospital','Ameerpet','Ameerpet, Hyderabad','https://www.google.com/maps/search/?api=1&query=Ameerpet+Dental+Hospital+Hyderabad',['Dental']]
];
await mongoose.connect(process.env.MONGO_URI||'mongodb://127.0.0.1:27017/careconnect');
await Promise.all([Schedule.deleteMany({}),Doctor.deleteMany({}),Hospital.deleteMany({})]);const hs=await Hospital.insertMany(facilities.map(([name,area,address,website,specialties])=>({name,area,address,website,specialties,dataStatus:['Apollo Health City','KIMS Hospitals','Yashoda Hospitals','Continental Hospitals'].includes(name)?'verified-reference':'needs-verification',openingHours:'Verify directly with facility before visiting'})));
const profiles=[['Demo Dr. Ananya Rao','General Physician',0,600],['Demo Dr. Rahul Mehta','Pulmonologist',2,800],['Demo Dr. Priya Reddy','Dentist',13,400],['Demo Dr. Arjun Kumar','Cardiologist',1,900],['Demo Dr. Neha Sharma','Pediatrician',6,650],['Demo Dr. Vikram Singh','Dermatologist',3,700]];
const ds=await Doctor.insertMany(profiles.map(([name,specialty,idx,fee])=>({name,specialty,hospital:hs[idx]._id,consultationFee:fee,experienceYears:5,isDemo:true,active:true,qualifications:'Demo profile — replace with verified clinician credentials'})));
const date=new Date();date.setDate(date.getDate()+1);const dateStr=date.toISOString().slice(0,10);await Schedule.insertMany(ds.map(d=>({doctor:d._id,date:dateStr,startTime:'09:00',endTime:'12:00',slotMinutes:30,unavailable:[],demoOnly:true})));
const email=process.env.SEED_ADMIN_EMAIL||'admin@careconnect.demo',password=process.env.SEED_ADMIN_PASSWORD||'ChangeThisDemoPassword123!';await User.updateOne({email:email.toLowerCase()},{$set:{name:'CareConnect Admin',email:email.toLowerCase(),passwordHash:await bcrypt.hash(password,12),role:'admin'}},{upsert:true});console.log(`Seeded ${hs.length} facility records, ${ds.length} demo doctors, schedules for ${dateStr}, and admin ${email}. Verify all facility data before real use.`);await mongoose.disconnect();
